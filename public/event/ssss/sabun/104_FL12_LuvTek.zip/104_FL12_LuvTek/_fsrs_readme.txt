Sabun-Shuffle Summer Season
https://darksabun.github.io/event/ssss/venue/

Sabun-Shuffle Summer Season - Freeroll -
https://venue.bmssearch.net/ssss_free

URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=143&event=137
Difficulty: FL12
Request: Using scratch LN (BSS)
Comment: based on 01_fuenec_spn.bms