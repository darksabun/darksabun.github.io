BMS chart Editors’ League
https://darksabun.github.io/event/bcel/venue/

BMS SEARCH venue: BMS chart Editors’ League -Preliminary-
https://venue.bmssearch.net/bcel_pre

URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=260&event=96
Difficulty: st3
Comment: 0.bbms基準
Violet Haze [410nm]より配置は簡単です。でも曲が長すぎ