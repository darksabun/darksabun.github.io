BMS chart Editors’ League
https://darksabun.github.io/event/bcel/venue/

BMS SEARCH venue: BMS chart Editors’ League -Preliminary-
https://venue.bmssearch.net/bcel_pre

URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=260&event=96
Difficulty: sl10
Comment: phup_unplaced.bms_基準
Lightの上限がライトではないと思っていましたが、実は下限もそれほどライトではありませんでした。