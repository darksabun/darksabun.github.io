本体URL：http://manbow.nothing.sh/event/event.cgi?action=More_def&num=74&event=132
_0.bms準拠
