원본 패턴	★12 compressed eyes -kusomiso-
재해석 패턴	★10 compressed eyes [Rigged]
본체 URL : http://onedrive.live.com/?id=FC95A680740CA8C9!111&cid=FC95A680740CA8C9#id=FC95A680740CA8C9%21137&cid=FC95A680740CA8C9

재해석한 이유
- compressed eyes는 특유의 플레이 감각이 상당히 잘 살아있는 노래이고, 특히 ★12 compressed eyes -kusomiso-의 타격감이 상당히 인상적이었다. 하지만 특유의 낮은 TOTAL과 플레이하기 까다로운 이중 계단이 즐기기에는 여의치 않은 난이도라고 생각한다. 따라서 해당 부분 및 어려운 계단들을 나만의 방법으로 재해석 및 약화하였다.

기타 코멘트
- compressed-kusomiso.bme와 비교하여 48~51마디에 엇갈림이 있으나, 원래 패턴이 노트별 간격이 일정치 않아 사운드에 위화감이 발생하는 구간이 있어 일정한 박자로 수정한 "의도된 엇갈림"입니다.