원본 패턴	★1 FELYS (虎のANOTHER)
재해석 패턴	★25 FELYS [MAXIMIZE]
본체 URL : http://web.archive.org/web/20070111193502/www107.sakura.ne.jp/~onoken/htmls/bms.html

재해석한 이유
- 발광의 최저 레벨인 ★1을 최고 레벨인 ★25까지 끌어올려보자는 느낌으로 만들고자 했다.

기타 코멘트
- felys.bme와 엇갈림 없음.
- 표기를 ★25로 하긴 했으나, 누군가 칠 수 있으리라고는 생각지 않음.