원본 패턴: ★5 Funny Funky Freaky [HARD]
재해석 패턴: ★18 Funny Funky Freaky [Filthy]
재해석한 이유: 노래가 마음에 들어 조금 더 고난이도로 만들어보았습니다.
본체 URL: https://dl.dropboxusercontent.com/s/4qhvogqjk60urdb/Funny_Funky_Freaky.rar
이벤트 URL: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=225&event=96
기타 코멘트: 추가 키음을 모두 같은 폴더에 넣어주세요.

原譜面: ★5 Funny Funky Freaky [HARD]
リメイク譜面: ★18 Funny Funky Freaky [Filthy]
リメイクした理由: 曲が気に入ってもう少し高難易度に作ってみました。
本体URL: https://dl.dropboxusercontent.com/s/4qhvogqjk60urdb/Funny_Funky_Freaky.rar
イベントURL: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=225&event=96
コメント: 追加音源をすべて同じフォルダに入れてください。

Original Chart: ★5 Funny Funky Freaky [HARD]
Reinterpreted chart: ★18 Funny Funky Freaky [Filthy]
Reason for reinterpretation: I liked the song, so I made it a bit more difficult.
BMS URL: https://dl.dropboxusercontent.com/s/4qhvogqjk60urdb/Funny_Funky_Freaky.rar
Event URL: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=225&event=96
Other comments: Put all the additional key-sounds in the same folder.