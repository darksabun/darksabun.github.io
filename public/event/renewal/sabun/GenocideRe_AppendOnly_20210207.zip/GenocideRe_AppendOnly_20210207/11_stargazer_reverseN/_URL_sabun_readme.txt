원본 패턴: ★11 Stargazer [流星雨が降る夜に]
재해석 패턴: B2 Stargazer [Ondomizer]
재해석한 이유: Ondo + Randomizer
본체 URL: https://onedrive.live.com/?authkey=%21ACus%5FtYiwMpTc6A&id=B32C1D1F5C2CC841%21111&cid=B32C1D1F5C2CC841#authkey=%21ACus%5FtYiwMpTc6A&cid=B32C1D1F5C2CC841&id=B32C1D1F5C2CC841%21132&parId=B32C1D1F5C2CC841%21111&action=defaultclick
이벤트 URL: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=60&event=76
기타 코멘트: 나는 차분을 짰다

原譜面: ★11 Stargazer [流星雨が降る夜に]
リメイク譜面: B2 Stargazer [Ondomizer]
リメイクした理由: Ondo + Randomizer
本体URL: https://onedrive.live.com/?authkey=%21ACus%5FtYiwMpTc6A&id=B32C1D1F5C2CC841%21111&cid=B32C1D1F5C2CC841#authkey=%21ACus%5FtYiwMp
イベントURL: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=60&event=76
コメント: 私は差分を作った

Original Chart: ★11 Stargazer [流星雨が降る夜に]
Reinterpreted chart: B2 Stargazer [Ondomizer]
Reason for reinterpretation: Ondo + Randomizer
BMS URL: https://onedrive.live.com/?authkey=%21ACus%5FtYiwMpTc6A&id=B32C1D1F5C2CC841%21111&cid=B32C1D1F5C2CC841#authkey=%21ACus%5FtYiwMp
Event URL: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=60&event=76
Other comments: I MADE CHART