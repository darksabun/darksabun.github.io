Title: Gimme All The Cocaine [W]

Obj: w

本体/Song URL: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=40&event=131

タグ/Tag: B14 中級者（やさしいソフラン）

推定難易度/Estimated Difficulty: ★10

Zure check: _Gimme_All_The_Cocaine_A.bms

ポイント式/Point Expression (PYTHON): 
```python
# clear: 0=FAILED, 1=EASY, 2=NORMAL, 3=HARD, 4=FULLCOMBO, 5=PERFECT
# ex_score//(total_notes*2): score rate

def point_function(clear, ex_score, total_notes):
    return min(100,  
        [0,10,15,30,40,40][clear] +
        max(0, int(100*ex_score/(total_notes*2) - 35))
    )
```

ポイント説明/Point Explanation:

# CLEAR (max 40pts)
>=EASY: +10
>=NORMAL: +5
>=HARD: +15
>=FULLCOMBO: +10

# SCORE RATE (max 65pts)
 (score rate * 100) - 35pts
<=35% = 0 pts
40% = 5 pts
...
65% = 30 pts
70% = 35 pts
75% = 40 pts
80% = 45 pts
85% = 50 pts
90% = 55 pts
95% = 60 pts
100% = 65 pts
(e.g. 27% = 0pts, 92% = 62 pts)

FULLCOMBO + 95% = 100pts

-------------------
Comment: 

Recommend MAX BPM FIX

Soflan is a strange thing. For example, this song (Gimme All The Cocaine) is 96-198bpm. The first half of the song is in 96bpm, and the second half is 198bpm. Reading at 0.5x scroll speed is very difficult, but this song becomes very easy if you gear change between the first and second halves of the song. Because there is no need to read at 0.5x scroll, it doesn't feel like a soflan song at all.

I think soflan patterns can be cool when the chart suddenly speeds up or slows down, like a rollercoaster. Soflan gives a lot of emphasis to intense or slow parts of the song, which can make the chart very exciting to watch and play. However, soflan is often annoying to the average player, because they may need to memorize gear changes to play the chart properly. Also, most soflan are 0.5x or 2.0x speed (like 100-200-400bpm), which can be quite difficult to read without a gear change.

The concept for the "Gentle Soflan (やさしいソフラン)" tag is to create a soflan chart that is easy for the average player to play, without needing to memorize gear changes. The two main ideas are:
- BPM changes are slight (not 0.5x or 2.0x), so the average player can still read the slow patterns without a gear change.
- The BPM changes often, so that gear changing is not a good strategy.
My objective is to create a soflan chart that is comfortable for first-time play.
Also, the player is encouraged to read slow notes, instead of using gear changes.

The final chart is 140~196bpm. I use a few different BPMs: 140,154,168,182,196, which are 10/14=71.4%, 11/14, 12/14, 13/14, 14/14=100% scroll speed respectively. I use a time signature trick to ensure the song stays the same: For example, if I want 11/14 scroll speed, I will set the BPM to 154, and set the time signature of the measure to 11/14=0.7857142857142857 by editing the bms in a text editor. I only change scroll speed at the start of the measure, because otherwise it would be too complicated.

I used a Python script to generate the "BPM charging" effect during the starting and ending BSS note.

I made most of the chart while streaming on Twitch. However, even though I had finished charting every part of the song at the end of the broadcast, it doesn't mean my chart is complete. Most of the time is spent on checking and test playing. I think it is important to repeatedly visually check the patterns by watching the autoplay and test play the chart, so I can make adjustments.

For example, I made plenty of adjustments to the chordstream sections of the chart offline. When I initially make the chordstream sections, I tend to arbitrarily place notes because it is faster to do. However, arbitrarily placed chordstreams tend to be uninteresting to play. Later on, what I like to do is to listen to the music and watch the chart over and over again, and try to adjust the patterns in the chordstream to more closely fit the flow of the music. For this chart, I added gaps, gachi and large chords in the streams to emphasize big sounds, and changed some of the streams to trills to emphasize the wobble bass. 

I think the most obvious feature of this chart is the long trill. The long trill plays at 196bpm, but it displays 168bpm because it is moving at 85.7% scroll speed. This was something I made in the beginning. It was supposed to be a temporary pattern, because I know many people don't like long trills. But it turned out to be incredibly fun to play (for me).
After playing it lots of times, on different randoms, on both keyboard and controller, without FAST/SLOW on, I decided that it's not difficult at all...? Or do I just have a strange skill set?

I find that it's easy to position your hands to get ready for the trill, because the measure before the trill scrolls slowly at 140bpm (~71.4% scroll), so you have time to see which two buttons the trill is on and get ready. On controller, I usually use two hands to do the trill. But if the trill is on keys 2+4 (I'm P2), I will use my middle and index finger on one hand. On keyboard, I will use my index and middle finger on one hand to do the trill if I get 1+2 or 6+7 (I play SDF space L:").

Other than the trill, I think this chart should be quite comfortable to play. Hopefully it is fun and exciting like a good soflan chart should be.

-------------------

IR BATTLE: https://darksabun.github.io/event/irbattle/

Website:https://wcko87.github.io/
Twitter:https://twitter.com/wcko87
自作譜面の難易度表:https://wcko87.github.io/bms-table/obj-w.html