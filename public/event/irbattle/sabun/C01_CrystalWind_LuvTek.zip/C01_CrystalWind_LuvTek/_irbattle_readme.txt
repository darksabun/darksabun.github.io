https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

本体URL 
http://web.archive.org/web/20040411171700/http://in-bpms.hp.infoseek.co.jp:80/BMS2.htm
[上級者IR（微連打）]
推定難易度: ★22?

Point expression 
min(100, min(30,clear*10)+max(0, (120-BP)/4)+30*(EXscore/(2*totalNotes))+20*(maxCombo/totalNotes))
Therefore, for clear: failed 0pts, EC 10pts, GC 20pts, HC 30pts

Comment
追加音源によるズレあり
★14의 Crystal Wind [UV]를 보고, UV 말고 IR도 있으면 어떨까 해서 만들었습니다.
처음에는 키음을 거의 다 사용해서 ★24 상급의 패턴이 나왔지만, 난이도의 인플레이션을 우려해 누구나 즐길 수 있을 정도로 약화했습니다.
광자 하나의 에너지는 UV가 IR보다 크지만, 어찌하다 보니 UV보다 더 어려운 IR이 되었습니다.