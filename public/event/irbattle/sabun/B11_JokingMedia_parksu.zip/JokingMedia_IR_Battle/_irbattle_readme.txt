https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

本体URL 
https://web.archive.org/web/20030223034539/http://cyclonearea.uhome.net:80/download/bms/media.exe
[ 中級者IR（2鍵）]
推定難易度: B-4?

Point expression
[0,10,20,90,100][min(clear,4)]

Comment
Just Kidding~