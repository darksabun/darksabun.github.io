SONG URL : http://manbow.nothing.sh/event/event.cgi?action=More_def&num=599&event=110
TAG : 高BPM
推定レベル：★22-23?
POINT : [{60*(SCORE/6226)}+10(FAILED) or 20(EASY CLEAR) or 30(GROOVE CLEAR) or 40(HARD CLEAR)]
COMMENT : BGA GIRLS KAWAII

Hard Spice(Hyper).bms基準ズレ抜けなし。
