LR2IR BATTLE : https://darksabun.github.io/event/irbattle/

http://manbow.nothing.sh/event/event.cgi?action=More_def&num=80&event=133
中級者IR (VERYHARD判定)
sl5???

0%(NOPLAY) = 0点 / 67.99%以下=40点 / 68~72.99%=50点 / 73~77.99%=60点 /
78~82.99%=70点 / 83~87.99%=80点 / 88%以上=90点
フルコン=10点追加

cocoa is cute

SPHARDとズレなし

07/25 fix percentage

08/06 fix pattern, fix percentage
