https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

本体URL 
https://venue.bmssearch.net/bmsshuin2/29

[初級者IR（ギミック）]
推定難易度: ★???(!?17ぐらい)

Point expression 
min(25 * Clear, 100)
Failed = 0
Easy Clear = 25
Clear = 50
Hard Clear = 75
Full Combo = 100

Comment
追加音源有り。ギミックを追加しているのでズレチェック不可。
いつもよりは地力寄りのギミック譜面です。より良いクリアランプを狙ってほしさの点数式です。
そこそこ覚える要素が多いので回数をこなしましょう。回数を稼ぐことは悪いことではないですぞ。
