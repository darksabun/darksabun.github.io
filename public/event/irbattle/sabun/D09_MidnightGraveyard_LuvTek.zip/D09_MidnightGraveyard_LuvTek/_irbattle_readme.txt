https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

本体URL 
http://manbow.nothing.sh/event/event.cgi?action=More_def&num=390&event=133
[(^^)IR（スイング）]
推定難易度: B5

Point expression 
min(100, [0,10,20,30][min(clear,3)]+max(0, 71-BP)+17*(EXscore/(2*totalNotes))

Comment
kari another (초기판 another)와 비교 시 엇갈림 없음
kari another 보관
https://www.dropbox.com/s/etw971zy94lkefw/Midnight%20Graveyard_A.bms?dl=1

플레이는 짧고 굵게