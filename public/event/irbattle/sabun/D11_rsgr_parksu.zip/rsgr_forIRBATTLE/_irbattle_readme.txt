https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

本体URL 
https://web.archive.org/web/20120623132756/http://diverse.jp/download/rsgr.rar
[ (^^)IR（2鍵）]
推定難易度: B0?

Point expression 
100*rate

Comment
OPEN YOUR EYES...AND FOCUS!