https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

(2021-07-18) fixed #085, #090-091

本体URL 
http://web.archive.org/web/20021227011400/http://www.ismusic.ne.jp/yossy/music_data/bms/k_snow.rar
[(^^)IR（長尺）]
推定難易度: st6? (★24強)

Point expression 
min(100, [0,20,30,40][min(clear,3)]+max(0, (200-bp)/4)+20*rate)
Therefore, for clear: failed 0pts, EC 20pts, GC 30pts, HC 40pts

Comment
追加音源によるズレあり
난이도 표기는 24이지만, 24치곤 강하기에 (^^)IR에 투고합니다.
마지막 회복이 많아서 클리어 자체는 싱거울지도 모르겠네요.