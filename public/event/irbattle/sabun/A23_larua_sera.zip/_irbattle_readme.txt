|=-------------------------=|
|=--{ larua [malicious] }--=|
|=-=-=-=-=-=-=-=-=-=-=-=-=-=|
|=--------{ NAGI }---------=|
|=-{ A23 }---{ obj. sera }-=|
|=-------------------------=|

--[ URL

https://drive.google.com/file/d/1uEvZtfypbEbeMnhQjxYyUCrCT_Wtd7Ie/view?usp=sharing

--[ TAG

장척/長尺/Long Distance

--[ Estimated difficulty

★5

--[ Point expression

combo/1035

--[ Comments

Combo is all you need.
Patterning is focused on melody and percussion renda is scattered around. Hopefully this one is actually not difficult...

Thanks for LuvTek for suggesting this song.