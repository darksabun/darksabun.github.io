https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

本体URL 
https://yosk.ojaru.jp/bmsyosk2.html#105
[ 初級者IR（主催）]
推定難易度: ★1

Point expression 
100*rate

Comment
普通の乱打？