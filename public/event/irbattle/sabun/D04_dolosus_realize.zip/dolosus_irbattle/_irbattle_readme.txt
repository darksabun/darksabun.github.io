https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

本体URL 
https://sound.jp/brilliantharmony/
[ (^^)IR（ガチ押し）]
推定難易度: st8?

Point expression 
rate+(100-rate)/2*(clear>0) if clear<2 else 100

Comment
がんばれ
(Object by 2RLZ + И)