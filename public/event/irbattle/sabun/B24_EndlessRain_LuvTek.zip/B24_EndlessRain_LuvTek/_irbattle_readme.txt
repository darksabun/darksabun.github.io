https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

本体URL 
http://web.archive.org/web/20010502140211/http://www.ab.aeonnet.ne.jp/~ken-x/bms.html
[中級者IR（超長尺）]
推定難易度: B-1 (★17???)

Point expression 
10*min(3, clear)+max(0, 32-max(2, BP))+20*(EXscore/(2*totalNotes))+20*(maxCombo/totalNotes)
Therefore, for clear: failed 0pts, EC 10pts, GC 20pts, HC 30pts

Comment
追加音源によるズレあり
익명 아닌 익명 투고