https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

本体URL 
https://mega.nz/folder/sZMTGZqZ#YZH2Xy6jBMMNl3MvQ_pp-A/file/YU0kGRqT

[中級者IR（主催）]
推定難易度: ★12?

Point expression 
50*(EXscore/(2*totalNotes))+50*(maxCombo/totalNotes)

Comment
追加音源によるズレあり
IR Battle Edition이지만 키음을 자른 것 외에 변화는 없습니다.
뒤로 갈수록 어려워지는 구성이라 밸런스는 나쁠 수 있지만, 곡 특성상 어쩔 수 없었습니다(?)
원래는 자체 어레인지 버전을 만들었지만 밸런스가 더 나빠서 공개를 보류했습니다.