https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

����URL: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=297&event=123
Tag: �ϼ���IR (�ǥ��쥤)
Estimated Difficulty: ��24
Point expression: ((min(clear lamp,3.2)+5)^2-25)/42.24*50 + (max(0,max combo-200)/(total notes-200))*15 + (max(0,score/total notes/2-0.4))/0.6*35

Comment: No misalignment compared with cipher_7N.bms