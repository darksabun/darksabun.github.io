Song URL : https://venue.bmssearch.net/bmstukuru2020/42

Difficulty : sl12
Total : 620

Diff Check : 동봉된 SPA와 비교 시 즈레 없음

Comment : 중속 고밀도 폭타를 연습하고 싶어서 짠 채보입니다. 짜다보니 sl12에 있는 "A D D i c T i O N 4 5 0 0 0 0 0 -L u N A-"와 성향이 매우 비슷해졌네요.