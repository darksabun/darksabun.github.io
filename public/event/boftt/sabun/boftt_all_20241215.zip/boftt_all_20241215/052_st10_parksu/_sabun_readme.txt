本体URL：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=52&event=146

_BEAT.bmlと比較してズレないことを確認しました。