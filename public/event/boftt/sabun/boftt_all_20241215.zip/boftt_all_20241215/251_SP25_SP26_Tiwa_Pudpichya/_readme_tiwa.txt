Kolorabaso ◎□■↑↓≡ / □□■■↑↑↓↓≡≡
Luminate / BG by Ash ash 鵝肝醤 / obj Tiwa Pudpichya

本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=251&event=146
推定レベル：★25 (◎□■↑↓≡) / ★26 (□□■■↑↑↓↓≡≡)

同梱のbbb - 副本.bms基準ズレ抜けなし。
よろしくお願いします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2024/11/14