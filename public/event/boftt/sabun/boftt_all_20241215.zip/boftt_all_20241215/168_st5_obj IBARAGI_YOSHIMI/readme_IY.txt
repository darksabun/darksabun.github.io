celestial serenity [N E O J A C K]

BPM130:ガチ押し 推定難易度:st5 NOTES:2947 TOTAL:551

同梱譜面(___normal.bms)と比較してズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=168&event=146