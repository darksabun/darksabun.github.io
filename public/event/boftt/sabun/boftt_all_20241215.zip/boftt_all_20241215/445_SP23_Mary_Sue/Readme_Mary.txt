E.V.E.R[MARYTHER]
SOMON / obj: Mary_Sue

本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=445&event=146
推定レベル：★23

_SP_no_pattern.bmsとずれ抜けなし
よろしくお願いいたします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2024/10/27