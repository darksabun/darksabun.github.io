Revived Lights [SP Resurrection]
Kalse feat. Hatsune Miku / obj:Mary_Sue

本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=276&event=146
推定レベル：★23-24

同梱Another基準ズレ抜けなし
よろしくお願いいたします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2024/12/01