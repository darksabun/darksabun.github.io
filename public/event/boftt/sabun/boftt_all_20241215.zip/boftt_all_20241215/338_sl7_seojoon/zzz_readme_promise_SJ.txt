For 「BOF:TT差分企画」

URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=338&event=146
Level: sl7?

동봉 미배치 파일과 즈레가 없습니다.
同梱未配置ファイルとスレがありません。

Comment: 
  만들고나서 보니 발광과 후살이 꽤 살벌한 녀석이 나왔습니다. 직접 테스트할 때 클리어가 잘 되지 않았기 때문에 sl8 이상일지도 모른다고는 생각합니다만, 제 지력이 줄었을 수도 있으니 난이도는 일단 sl7이라고 해두었습니다. 정확한 책정은 여러분들께 맡길게요?

2024.11.4 seojoon