Magical Night Special [サメ]
Song URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=413&event=146
Estimated Difficulty: sl4 (★7)
Based on SPB
( https://drive.google.com/file/d/1kp8PjJHDGmZfH9yk-6kBbZv7StNDRy9d/view )