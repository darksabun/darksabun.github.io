夢ここに在らず [newgame+]
Song URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=352&event=146
Estimated Difficulty: sl2（★3~4）
Based on SPN