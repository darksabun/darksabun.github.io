Euclides
Agate ∧ MIPSYLE (movie : SUI)

obj  Иuclein / ∀tharnal

本体 : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=47&event=146
推定レベル：st9

ズレ チェック :  _Euclides_SPA.bms とのズレなし

Comments

∀tharnal
  - 最上位のステラは初めてです。よろしくお願いします。

Иuclein
 - 140bpmのガチ押しが不可能な人です。よろしくお願いします。


discord
 -Atharnal (discord : Atharnal#2977)
 -Nuclein (discord : Nuclein#5741)