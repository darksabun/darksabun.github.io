Centurion
(st3?) [Struggle]
(st7?) [Triumph]

本体URL:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=70&event=146

ズレ抜けについて
	両差分とも、キー音の追加を除きズレ抜け無し
	同梱[Another](7key_Another.bms)とbms diff toolで比較して、ズレ抜けが無いことを確認しています