・Song URL : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=445&event=142

・Difficult: sl12

・#145~146のズレ抜け意図的(追加キー音)