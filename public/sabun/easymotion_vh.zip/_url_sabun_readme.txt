曲名と差分名：easymotion [-]
差分作者名義：(^v^)/
原曲URL：http://liz.nothing.sh/xrv/easymotion.zip
イベントURL：http://manbow.nothing.sh/event/event.cgi?action=More_def&num=50&event=76
難易度：B0?
チキンレースへの参加：X
コメント：散歩していて思い出したアイデアで適当に作りました。すみません。(for oraja) LNMODEは強制的にLNにしています。