本体URL：https://onedrive.live.com/?authkey=%21AIr4v9MWBYrS9h8&cid=FC95A680740CA8C9&id=FC95A680740CA8C9%21441&parId=FC95A680740CA8C9%21428&o=OneUp
追加音源：https://bms.hexlataia.xyz/tables/hexajoy.html