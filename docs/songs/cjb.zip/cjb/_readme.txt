This is a BMS for a high school arts festival held in September 2016.
Due to the limited number of simultaneous inputs of the keyboard in the high school, most charts are 5+1keys.
If you're wondering who DJ Ahn is, open the file.