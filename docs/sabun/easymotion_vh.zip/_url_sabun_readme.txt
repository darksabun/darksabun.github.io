曲名と差分名：easymotion [-]
差分作者名義：(^v^)/
原曲URL：http://liz.nothing.sh/xrv/easymotion.zip
差分URL：https://darksabun.github.io/sabun/easymotion_vh.zip
イベントURL：http://manbow.nothing.sh/event/event.cgi?action=More_def&num=50&event=76
難易度：B0?
コメント：散歩していて思い出したアイデアで適当に作りました。すみません。(for oraja) LNMODEは強制的にLNにしています。