﻿曲名と差分名：azule twilight [Healing]
差分作者名義：(^ω<)/
原曲URL：http://web.archive.org/web/20030609231459if_/http://careless.hp.infoseek.co.jp:80/e_vision.rar
難易度：Σ；3 」 ∠ )ﾐ⌒ゞ
チキンレースへの参加：X
コメント：TOTAL103をあげようか悩みましたが50%引き上げました