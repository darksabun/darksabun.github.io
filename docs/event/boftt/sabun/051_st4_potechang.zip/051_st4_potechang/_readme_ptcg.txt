(st4?) complement [completion]

本体URL:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=51&event=146

ズレ抜けについて
	意図的なキー音の追加があります
	同梱[ANOTHER](_complement_7a.bms)とbms diff tool比較して、ズレ抜け無し