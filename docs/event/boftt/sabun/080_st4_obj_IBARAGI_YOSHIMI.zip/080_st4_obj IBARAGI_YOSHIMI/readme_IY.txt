SUNRISE OCEAN -Sol-

BPM:145 推定難易度:st4 NOTES:3365 TOTAL:655

同梱譜面(_SPN.bms)と比較してズレ抜け無し

本体URL
　→https://manbow.nothing.sh/event/event.cgi?action=More_def&num=80&event=146