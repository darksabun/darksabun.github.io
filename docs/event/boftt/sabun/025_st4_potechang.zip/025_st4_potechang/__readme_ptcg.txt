(st4?) SYNCLiNC [RESONAnCE]

本体URL:
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=25&event=146

ズレ抜けについて
	意図的なキー音の追加があります
	同梱[SP ANOTHER](spa.bms)とbms diff toolで比較して、ズレ抜け無し