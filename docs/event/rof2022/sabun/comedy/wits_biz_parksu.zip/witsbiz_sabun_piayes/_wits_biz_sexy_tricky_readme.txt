BMS DL : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=384&event=137

동봉한 파일을 모두 BMS 파일과 같은 곳에 넣어주세요. (어레인지로 인한 즈레 있음)

同梱のファイルを全て同じフォルダに入れてください。
アレンジした差分なのでズレがあります。