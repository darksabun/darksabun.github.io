[Achilles 588]

曲URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=86&event=140
難易度: fr8? (SB8?)

notes: 1972
scratch: 588
total: 588 (rate=0.23)

同梱Anotherと比較しズレ抜けなし