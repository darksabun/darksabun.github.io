https://manbow.nothing.sh/event/event.cgi?action=More_def&num=214&event=140

DIFFICULTY: B4
NOTES: 1990
TOTAL: 398
JUDGERANK: EASY

同梱T03_SPH.bms基準