https://manbow.nothing.sh/event/event.cgi?action=More_def&num=163&event=140

DIFFICULTY: st3
NOTES: 2390
TOTAL: 435
JUDGERANK: EASY

同梱N.bms基準
基準追加音源あり