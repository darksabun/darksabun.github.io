Black Wings [Maryther]

本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=448&event=140
推定レベル：★19-20? (st0程度)
同梱Normalベースです。

よろしくお願いいたします。
Mary_Sue (https://darksabun.github.io/Mary_Sue/)
2022/11/24