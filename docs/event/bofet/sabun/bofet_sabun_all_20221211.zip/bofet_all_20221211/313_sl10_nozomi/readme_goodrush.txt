차분명 : LUNATIC

테스트 : sl10?

비교 : SPA 기준 중복음 제외 즈레 X

원곡 URL : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=208&event=313

코멘트 : EBIMAYO님의 국밥 시리즈는 들으면 들을수록 재밌어