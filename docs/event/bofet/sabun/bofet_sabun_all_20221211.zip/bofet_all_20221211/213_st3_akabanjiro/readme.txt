本体リンク:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=213&event=140
推定難易度:st3