(´0｀*)♪(≧Σ≦)♪(・ε・。)♪(￣∇￣；)♪（0∀0）=3♪o(･_･θ [SP MARYTHER]

本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=312&event=140
推定レベル：★21? (st1-st2)
同梱NORMALベースです。

よろしくお願いいたします。
Mary_Sue (https://darksabun.github.io/Mary_Sue/)
2022/11/25