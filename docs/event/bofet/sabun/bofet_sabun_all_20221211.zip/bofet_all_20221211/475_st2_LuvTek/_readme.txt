https://manbow.nothing.sh/event/event.cgi?action=More_def&num=475&event=140

DIFFICULTY: st2
NOTES: 2949
TOTAL: 449
JUDGERANK: EASY

同梱_N.bms基準