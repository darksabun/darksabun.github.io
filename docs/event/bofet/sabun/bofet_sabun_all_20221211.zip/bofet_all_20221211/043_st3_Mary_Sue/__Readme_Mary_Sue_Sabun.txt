The Photons of Music [SP ECSTATIC]

本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=43&event=140
推定レベル：★22-23? (st3程度)
同梱の0_PhotonsofMusic_empty.bmeがベースです。よろしくお願いいたします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/)
2022/11/17