Stars Keep on Illuminating by Anco

[13-A] Difficulty: sl2 (★2?)

Uses template file (_stars_keep_on_illuminating_0_0.bml.noobj)
Wanted to make something to bridge the gap between Another and Insane, still ended up being too easy.

Song DL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=12&event=140