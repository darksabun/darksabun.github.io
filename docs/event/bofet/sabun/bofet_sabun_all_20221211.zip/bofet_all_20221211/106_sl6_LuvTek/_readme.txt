https://manbow.nothing.sh/event/event.cgi?action=More_def&num=163&event=140

DIFFICULTY: sl6
NOTES: 1943
TOTAL: 243
JUDGERANK: NORMAL

同梱ThingsofPeculiarNature.dummy基準