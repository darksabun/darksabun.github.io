★24/st5? 熱帯夜の祭り [EX]

ARTIST:    Pica X M2U (obj:EGRET.)
SUBARTIST: Movie:PressVisualer


The 同時押し譜面
同梱hyper譜面と比較してズレ抜けなし（AnzuBMSDiffで確認済み）

EGRET.

