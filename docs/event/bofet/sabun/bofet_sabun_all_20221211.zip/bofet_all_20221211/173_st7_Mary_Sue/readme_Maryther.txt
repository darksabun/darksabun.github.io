Sylph (SP MARYTHER)

本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=173&event=140
推定レベル：★★5? (st7ぐらい)
同梱BEGINNERベースです。 

BOF:ET差分企画のラスボス感じの譜面です。（せめて私が作った譜面のうちでは）
どうぞよろしくお願いいたします。
Mary_Sue (https://darksabun.github.io/Mary_Sue/)
2022/11/29