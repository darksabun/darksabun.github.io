家物語 [SP MARYIETHER]

本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=418&event=140
推定レベル：★24? (st4程度)
同梱の_ie.bmsがベースです。よろしくお願いいたします。

Mary_Sue (https://darksabun.github.io/Mary_Sue/)
2022/11/17 