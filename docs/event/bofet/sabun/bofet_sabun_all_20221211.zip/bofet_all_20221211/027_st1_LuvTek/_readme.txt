https://manbow.nothing.sh/event/event.cgi?action=More_def&num=27&event=140

DIFFICULTY: st1
NOTES: 2565
TOTAL: 365
JUDGERANK: EASY

同梱0_strange_empty.bmx基準