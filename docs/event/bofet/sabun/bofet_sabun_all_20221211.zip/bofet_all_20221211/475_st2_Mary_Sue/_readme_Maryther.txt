Clever machine Crazy [MARYTHER] 

本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=475&event=140
推定レベル：★22?
同梱NORMALベースです。

よろしくお願いいたします。

Mary_Sue
2022/11/22