URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=171&event=137

Difficulty: 5keys ☆?
Comment: 同梱に14鍵しかない & 5鍵が似合いそうだったので
