https://manbow.nothing.sh/event/event.cgi?action=More_def&num=412&event=137


sl3等級：
[高負荷IIIのII]ノーツの数が大幅に増加
[火力減衰II] ゲージの上昇幅がさらに減少
[視程不良II] ノーツの判定がさらに強化（HARD)
[炎の地形]　[峻険地形I]は失効して、 スクラッチする時鍵盤数が増加
[幻惑配置II]　曲にBPMもっと変動する　
[失敗幻覚]　３回も失敗しました…か？