URL : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=15&event=137
DP★8~10
DP★12~13 [ 製作中 ]

LuvTekさんはMAX BPMに影響を与えないギミック関連でサポートしてくれました。
ありがとうございます。