LINK : http://manbow.nothing.sh/event/event.cgi?action=More_def&num=27&event=101
LEVEL : ★★鷺

이것은 정리된 차트이므로 정확한 즈레을 확인할 수 없습니다.