reveL [7 Ex]
★22 (st2~st3)
-> https://manbow.nothing.sh/event/event.cgi?action=More_def&num=158&event=140