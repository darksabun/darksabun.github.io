・Song URL : https://drive.google.com/file/d/1SuDVtZNb0o8WyFim2LtCfvq0mply8_ZY/view

・Difficult: st0

・キー音追加と曲アレンジがあります。ズレチェック不可。