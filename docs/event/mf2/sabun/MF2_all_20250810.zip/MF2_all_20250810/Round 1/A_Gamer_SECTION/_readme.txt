원곡 : A Gamer Never Showed Up For PABAT. This Is What Happened To His Brain.
아티스트 : ProjectG
원곡 링크 : https://k-bms.com/party_pabat/party.jsp?board_num=25&num=49&order=reg&odtype=a

차분 제작 : SECTION
차분명 : A Gamer Never Showed Up For PABAT. This Is What Happened To His Brain. [!]
난이도 : st1~2?

기타 :
전용 BGA가 동봉되어 있습니다. 파일명은 차분과 동일합니다.
그 외 키음 배치에 엇갈림은 없습니다.