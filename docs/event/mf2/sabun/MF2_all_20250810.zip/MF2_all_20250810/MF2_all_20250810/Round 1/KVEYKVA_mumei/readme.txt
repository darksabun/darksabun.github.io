BOFXVII : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=132&event=137
DL : https://drive.google.com/file/d/1uj_CJy45FOjlABsSZgRnlhHQ8ctIeen1/view
sl11?
KVEYKVA_A.bmsと比較しズレなし