RearDawn remixed by LU - Backpacker(remix) [/]
obj. SECTION
BMS: http://docs.google.com/uc?export=download&id=1CM1RNI6Ufoiq5BKXT6tSyufegCmECobD
Difficulty: ★12?