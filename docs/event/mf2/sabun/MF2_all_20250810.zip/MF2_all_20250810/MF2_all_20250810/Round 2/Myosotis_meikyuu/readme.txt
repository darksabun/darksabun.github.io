Myosotis [sylvatica]
椿./movie.D・ENNY/ill.のこのこ
obj. 迷宮兄弟

推定レベル : ★8~9?
本体 : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=200&event=142

2作目になります。よろしくお願いいたします。