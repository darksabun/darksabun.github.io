# URL
http://web.archive.org/web/20020819025557/http://www.sasebo.ac.jp/~e9816/mp_E3BGAIN.exe

# Difficulty
��18

# Comment
`___bga.bms` � keysound misalignments �Ȃ��B
