Sabun-Shuffle Summer Season
https://darksabun.github.io/event/ssss/venue/

Sabun-Shuffle Summer Season - Freeroll -
https://venue.bmssearch.net/ssss_free

URL: https://archive.org/download/dj_fujii_bms/DJ_fujii_bms_collection.rar/DJ_fujii_bms_collection%2Fanachronism.rar
Difficulty: sl4
Request: ≥ 1200 NOTES by seojoon
Comment: a.bms基準 追加音源あり