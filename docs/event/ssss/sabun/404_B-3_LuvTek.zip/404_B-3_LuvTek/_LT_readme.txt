Sabun-Shuffle Summer Season
https://darksabun.github.io/event/ssss/venue/

Sabun-Shuffle Summer Season - Round 1 -
https://venue.bmssearch.net/ssss_1st

URL: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=200&event=133
Difficulty: B-3
Request: 10 times or more BPM changes by 2RLZ
Comment: based on 00_tamamo_spb.bms