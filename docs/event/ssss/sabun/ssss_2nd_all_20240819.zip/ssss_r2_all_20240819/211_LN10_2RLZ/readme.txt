https://darksabun.github.io/event/ssss/venue/
(Sabun-Shuffle Summer Season event page)

本体URL 
https://nekokan.dyndns.info/~pmcc/pmcc2/download.html
推定難易度: LN10?

Comment
よろしくお願い致します。