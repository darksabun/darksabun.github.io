Sabun-Shuffle Summer Season
https://darksabun.github.io/event/ssss/venue/

Sabun-Shuffle Summer Season - Round 2 -
https://venue.bmssearch.net/ssss_2nd

URL: https://dl.dropboxusercontent.com/s/x7bfe5rlauidc3o/GENDAI_GENSOU_KITAN.zip?dl=0
Difficulty: st3
Request: One or more types of gimmicks by くろ
Comment: based on `_BSaI_N.bms` with removing duplicate keysounds and decomposing `Kickroll.wav` to multiple `Kick.wav`.