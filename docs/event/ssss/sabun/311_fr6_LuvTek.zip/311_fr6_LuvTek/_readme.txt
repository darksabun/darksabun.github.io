Sabun-Shuffle Summer Season
https://darksabun.github.io/event/ssss/venue/

Sabun-Shuffle Summer Season - Freeroll -
https://venue.bmssearch.net/ssss_free

URL: http://sound.jp/bmstank1/at/AT14.rar
Difficulty: fr6
Request: Jacks
Comment: based on AT14.bms with additional keysounds