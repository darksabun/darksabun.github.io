BMS by SENS: https://web.archive.org/web/20041129052843/http://www.sango.sakura.ne.jp/~sens/bms/djsens_remix2.zip
Request (☆5): ≥ B1 by LuvTek
Difficulty: fr11

based on sens_remix2_veryeasy_7key.bms, large amount of intentional misalignments.
contains additional keysounds.