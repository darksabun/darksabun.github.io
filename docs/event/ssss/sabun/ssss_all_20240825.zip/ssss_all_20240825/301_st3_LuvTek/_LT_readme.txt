Sabun-Shuffle Summer Season
https://darksabun.github.io/event/ssss/venue/

Sabun-Shuffle Summer Season - Freeroll -
https://venue.bmssearch.net/ssss_free

URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=58&event=135
Difficulty: st3
Request: 「コントラスト」 by LuvTek
Comment: based on `1_WhiteLine.xxx` with replacing duplicate keysounds and decomposing `D_Kick_035.wav` to multiple `D_Kick_020.wav`.