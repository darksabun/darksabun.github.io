Eida. Change Of Clothes [Shapeshift]
dj BEATCONTROLLER / obj: Mary_Sue

本体：https://web.archive.org/web/20060113001716/http://biznot.biz/eida.zip
推定レベル：★17?
eidaanother.bmsとズレ抜けなし。

実はToy Musicalの曲であるAuthbach 2005の差分を作りたかったんですが、それはやはり2025年になったら作る方が良さそうです。今年の差分企画はこれで。
よろしくお願いいたします。

2024/02/09
Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
