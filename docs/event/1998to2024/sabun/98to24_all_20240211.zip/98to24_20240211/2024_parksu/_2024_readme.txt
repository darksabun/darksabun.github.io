Difficulty：☆7 ☆10 ☆12 ☆12 (NORMAL~BLANK CHECK 4譜面)

Comment：
Original song from OpenMSX. (https://github.com/OpenTTD/OpenMSX)
license is GPL v2. (see license.txt)

백지 수표에서 백지의 한자는 白紙가 아닌 白地라는 걸 이제서야 알았습니다.