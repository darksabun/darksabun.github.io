Song URL:https://onedrive.live.com/?id=FC95A680740CA8C9%21201&cid=FC95A680740CA8C9

ps_another.bmeと比較してズレ無し。

Song Comment:HAPPY SWEETS COREのファンです
Chart Comment:指ガチ譜面を初めて作ったので変な譜面になってるかもしれません 謝罪

