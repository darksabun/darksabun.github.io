本体URL：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=232&event=123
同梱12_rch_sph.bmsと比較しズレ抜け無し
難易度：★21ぐらい
微連打複合×ガチ押しをやりたかった。
