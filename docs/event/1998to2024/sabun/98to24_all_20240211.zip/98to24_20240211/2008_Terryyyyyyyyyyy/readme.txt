本体URL: https://drive.google.com/drive/folders/1pJ1Zs9ewUJTe9HbGD7ZX_Tu98E1voxDp
(BMS Library > A > Absurd Gaff)

Based on _ms_abs07_03.bme

Comment: 처음으로 7키 악보를 제작하였습니다. 잘 부탁드립니다.
I made a 7+1 Key Sabun for the first time. I look forward to your kind cooperation.
初めて7キーの楽譜を製作しました。 どうぞよろしくお願いします。