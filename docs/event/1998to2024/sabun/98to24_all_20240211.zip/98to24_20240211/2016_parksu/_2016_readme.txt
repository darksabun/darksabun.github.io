本体URL：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=528&event=110

7a.bms基準ズレ抜けなし。

Difficulty：B2

Comment：健全なる精神は健全なる身体に宿る！！！