Song URL : https://tm2.toymusical.net/download.html

Difficulty : st0
Total : 480

Diff Check : 동봉된 pms HYPER와 비교 시 즈레 없음

Comment : 키음이 FF까지만 지원하던 시기에 만들어진 곡이다보니 일부 키음이 한 개로 뭉쳐진 키음이 많았어서 그 키음은 무키음으로 대체하였습니다. 그래도 나름 잘 짜여진 것 같아서 만족스럽습니다.