Toujinbou ○↓†
こんなのでチルアウトしたくない obj. Tiwa Pudpichya

本体：http://gensoukyousoukyoku.nekokan.dyndns.info/downbeat_toujinbou.rar
推定レベル：★24?
5k.bmsとズレ抜けなし。

なんとなく2005年と2014年、二つの差分を作ることになりましたが…
やはり一人で二つの差分を作るのは難しいのでタイ王国に帰ったTiwa Pudpichyaさんに2014年差分の製作を頼みました。
今度もディレイ譜面だそうです。よろしくお願いいたします！ - Mary_Sue

สวัสดีค่ะ ดิฉันชื่อ ทิวา พุดพิชญา(Tiwa Pudpichya) ค่ะ ยินดีที่ได้มาร่วมงานนี้อีกครั้งค่ะ
Toujinbou เป็นสถานที่ท่องเที่ยวของประเทศญี่ปุ่นค่ะ Toujinbou ชาวพระที่มีชื่อนี้ ได้ตกจากที่นี่และเสียชีวิตไปค่ะ
ดังนั้น ฉันตั้งชื่อแพทเทิร์นที่สร้างขึ้นว่า ○↓† มาจากไอเดียในเรื่องนั้นค่ะ 
อาจจะลำบากไปนิดนึง แต่ขอให้คุณเล่นอย่างสนุกนะคะ แล้วค่อยเจอกันใหม่นะคะ See you later! - Tiwa Pudpichya

Tiwa Pudpichya (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2024/02/09 