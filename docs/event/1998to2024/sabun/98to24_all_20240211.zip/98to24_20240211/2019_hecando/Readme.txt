RIOT-CONTROL

URL : https://k-bms.com/party_pabat/party2019.jsp?board_num=19&num=36&order=reg&odtype=a

Difficulty : sl0

RC_BASE.bms と比較するとズレなし

Comment：ギター、ベース、ドラムの三人が揃えば最高！
		 演奏しやすい難易度のsl0くらいにしてみました。