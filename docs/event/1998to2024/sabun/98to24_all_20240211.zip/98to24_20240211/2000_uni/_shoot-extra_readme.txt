/***   Chart info   ***/

☆11(sl0) Shooting Star [Extra]
Notes:1215 / Total:400

Song URL : https://web.archive.org/web/20030429222056/http://www.ismusic.ne.jp:80/pinky/bms/shootingstar.rar

※追加音源を含んでいます。差分と一緒に導入してください



/***   ズレチェック  ***/

shootingstar_a.bmsと比較し、以下の3点について意図的なズレ抜けがあります。(ズレチェック不可)
・追加音源によるキー音のズレ抜け
・ソフラン除去によるズレ
・ミスと思われるキー音の削除



/***   comment   ***/

こんにちは、うにです
1998to2024の2000年担当ということで、以前より好きなBMSの1つであったPinky様のShooting Starで差分を作りました。
ちなみにShooting Star以外の候補はPOM様の「Angel (score attack edition)」、paraoka様の「rainy graveyard」、
cranky様の「snow」等がありました。
Shooting Starを選んだのは差分が殆ど作られていないことと、譜面が作りやすそうだったから...という理由からです

譜面に関しては古めの曲特有のキー音の少なさ等もあり配置に難儀しましたが、なんとか無難に遊べる形にまとまったかと思います。
☆12に片足突っ込むくらいの☆11といった感じの比較的遊びやすい難易度ですので、素晴らしい曲と一緒に楽しんでいただければ嬉しく思います。
