real worlds
----------------
BMS arrange: CAMEL (1998-11)
https://mega.nz/file/jWZHDQgB#DzEgGBFY6KASHijW9hWuUNu9Xs960vgwAxo52uQYDiA

Original: Elwood (XM releases)
https://www.elwoodproductions.com/

Additional keysounds using OpenMPT
https://openmpt.org/
----------------
[reasonable] ~sl1
[for some reason] ~sl9
[without reason] ~st2
[for DJ Ahn] ~B-1
----------------
Comments
I am not an atomic playboy!

1998년은 아무래도 오리지널 악곡보다는 카피 어레인지 BMS가 주역이던 시기가 아닐까 합니다.
그 중에서 저작권 걱정이 없는 BMS를 찾다가, 현재 무료공개 중인 모듈 음악을 기반으로 한 'real world'로 차분을 만들게 되었습니다.

원 BMS 자체는 키음으로 분리된 트랙이 몇 없기에, 모듈 파일에 기반해 키음을 새로 분리하였습니다.
또한, 원 BMS에 없는 트랙을 새로 추가해 조금 더 다채로운 구성이 되도록 하였습니다.

이쯤되면 차분인지, 카피 BMS의 카피 BMS인지 모르겠네요.
차분 난이도는 '1998 to 2020'에 제출한 'Out of the System'과 비슷한 구성이나, 조금 더 폭을 넓혔습니다.

4년만에 개최된 컨셉의 이벤트이므로, 다른 제출 차분과 같이 아무쪼록 잘 즐겨주셨으면 합니다.

1998年はオリジナル曲よりもコピーBMSが主役だった時期ではないかと思います。
著作権の問第がないコピアレBMSを探していて、無料公開中のモジュール音楽を原曲とした｢real world｣で差分を作りました。

元のBMS自体は音切られたトラックが数少ないため、モジュールファイルに基づいて追加音源を抽出しました。
また、元のBMSにないトラックを追加し、もう少し多彩な構成になるようにしました。

これくらいなら差分なのか、コピーBMSのコピーBMSなのかわかりませんね。
差分の難易度は'1998 to 2020'に提出した｢Out of the System｣と似た構成ですが、もう少し幅を広げました。

4年ぶりに開催されたコンセプトのイベントですので、どうぞよろしくお楽しみください。

1998 was a year when copied BMS took center stage rather than the original tracks.
I searched for copied BMSes without copyright issues, and Real World seemed to be the best candidate, based on module music currently available for free.

Since the original BMS separated the keysounds of a few tracks, I extracted additional keysounds based on the module files.
Furthermore, I added tracks not found in the original BMS for a more diverse experience.

So, it's unclear whether this is a chart of the "real world" or another copied BMS of the module music 🙃.
The difficulty range of the charts is similar to "Out of the System," submitted to '1998 to 2020', but slightly broader.

It has been 4 years since '1998 to 2020' was held, so I hope you enjoy playing the submitted charts for '1998 to 2024'.
----------------
pattern for some reason
https://fsrs.github.io/