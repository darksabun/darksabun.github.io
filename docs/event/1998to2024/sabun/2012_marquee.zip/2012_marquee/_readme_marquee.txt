★1 テキトウInfinite love(BMS edit) [EX]

BMS URL : https://dropbox.bms.ms/u/63612044/%E3%83%86%E3%82%AD%E3%83%88%E3%82%A6Infinite%20love.rar
Difficulty : sl1(★1)
Comment : Typical 地力 chart

No Misalignment (Based on tekitou_7.bms)