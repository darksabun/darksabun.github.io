URL : https://web.archive.org/web/20130512091940/http://ninjaactionteam.sakura.ne.jp/download/wasabi.rar

Comment : 2001년 생산된 BMS중 마음에 드는게 몇개 있었지만 그곡들은 DL이 없는 관계로 와사비로 대체 되었습니다.
현시대에 맞는 같이어시 차분들을 마음껏 짜봤습니다.

