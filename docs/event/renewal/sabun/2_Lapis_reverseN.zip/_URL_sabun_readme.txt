원본 패턴: ★2 Lapis [Another+]
재해석 패턴: ★1 Lapis [KF]
재해석한 이유: 연타가 치고 싶어서
본체 URL: http://shiki2.sakura.ne.jp/shiki_lapismq.rar
본체 URL (HQ): http://uploader.bms.ms/data/bof2008/shiki_lapisuq.rar
기타 코멘트: 나는 차분을 짰다

原譜面: ★2 Lapis [Another+]
リメイク譜面: ★1 Lapis [KF]
リメイクした理由: 連打が好きで
本体URL: http://shiki2.sakura.ne.jp/shiki_lapismq.rar
本体URL (HQ): http://uploader.bms.ms/data/bof2008/shiki_lapisuq.rar
コメント: 私は差分を作った

Original Chart: ★2 Lapis [Another+]
Reinterpreted chart: ★1 Lapis [KF]
Reason for reinterpretation: I want play Jacks
BMS URL: http://shiki2.sakura.ne.jp/shiki_lapismq.rar
BMS (HQ): http://uploader.bms.ms/data/bof2008/shiki_lapisuq.rar
Other comments: I MADE CHART