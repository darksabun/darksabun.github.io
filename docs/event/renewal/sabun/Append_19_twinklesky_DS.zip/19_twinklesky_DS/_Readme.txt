﻿원본 패턴 : ★19 ☆ twinklesky ☆ _16 MANIAQ
재해석 패턴 : ★21 ☆ twinklesky ☆ (B1)
재해석한 이유 : 저속 BPM이 고정인 차분은 구시대적이고 연습에 도움이 되지 않는다고 판단해서
본체URL : https://fether.exblog.jp/#BMS_fether
코멘트 : 추가 음원 및 BMP 파일 있음
어레인지 차분, 50% 확률로 클리어 난이도가 매우 높아짐