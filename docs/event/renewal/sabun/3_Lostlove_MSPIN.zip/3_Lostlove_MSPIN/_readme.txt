원본: ★3 Lostlove -BMS ver. another-
재해석 패턴: ★5 Lostlove -BMS ver.- (KF)
재해석한 이유: 縦連打 to 多要素
본체 URL: http://skydrive.live.com/?cid=FC95A680740CA8C9&id=FC95A680740CA8C9%21111
기타 코멘트: 딜레이로 인한 의도적 키음, BGA 재배치 존재
