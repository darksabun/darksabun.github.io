원본 패턴: ★1 Espresso Shots [convert]
재해석 패턴: B6 Espresso Shots [乱打と速度]
재해석한 이유: 스크롤이 일정한 기믹 실험
본체 URL: https://drive.google.com/uc?export=download&id=0B_zaXp2TGbT3VV9ISjVIRXFzRVU
이벤트 URL: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=39&event=96
기타 코멘트: 나는 차분을 짰다

原譜面: ★1 Espresso Shots [convert]
リメイク譜面: B6 Espresso Shots [乱打と速度]
リメイクした理由: スクロールが一定のギミック実験
本体URL: https://drive.google.com/uc?export=download&id=0B_zaXp2TGbT3VV9ISjVIRXFzRVU
イベントURL: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=39&event=96
コメント: 私は差分を作った

Original Chart: ★1 Espresso Shots [convert]
Reinterpreted chart: B6 Espresso Shots [乱打と速度]
Reason for reinterpretation: Gimmick experiment with constant scroll
BMS URL: https://drive.google.com/uc?export=download&id=0B_zaXp2TGbT3VV9ISjVIRXFzRVU
Event URL: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=39&event=96
Other comments: I MADE CHART