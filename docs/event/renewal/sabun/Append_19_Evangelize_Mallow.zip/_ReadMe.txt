原譜面: ★19 Evangelize (Radio Edit) (SP FRIDAY)
リメイク譜面: ★25 Evangelize (Radio Edit)
リメイクした理由: もっと押したくない？
本体URL:http://www.dropbox.com/sh/xrr3fvlhagzsmm2/AAC0HdK_kps6UCKtDFTCkpJea/bms/Evangelize%20(Radio%20Edit).rar?dl=0
コメント:私はクリアできません