원본 패턴: ★22 Tears of the Sunrise [No Future]
재해석 패턴: ★24 Tears of the Sunrise [No More Tears]
재해석한 이유: ★22에서 가장 좋아하는 작품입니다. 반복적이면서도 애수적인 신스음과 무기질적인 하이햇의 조합이 매력적입니다.
★22에 수록된 패턴은 키음의 사용이 다소 일관적이지 않고, 연타보다는 난타 배치이기에 이를 연타로 배치하여 매력적인 음을 충분히 즐길 수 있도록 구성하였습니다.
본체 URL: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=1&event=104
기타 코멘트: 제작자 본인이 클리어했으니 아마 ★★5까지는 아닐 것입니다. 동봉 SPN 기준 즈레 없음.