原譜面: ★19 resta del tramonto
リメイク譜面: ★17 resta del tramonto
リメイクした理由: ズレすぎてたから
本体URL:http://yaruki0.sakura.ne.jp/event/ondanyugi5/impression.cgi?no=39
コメント:こんなにも簡単になるとは...