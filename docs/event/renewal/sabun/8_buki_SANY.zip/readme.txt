原譜面: 舞姫 ～buki～　[7key AFOTHER]
リメイク譜面: 舞姫 ～buki～[7key LOFT]
リメイクした理由: 違和感があったので
本体URL:https://houjiroumpbt.wixsite.com/area-hj/bms
コメント:難しくなっております