原譜面: ★6 5.1.1(ReMix)[Afother]
リメイク譜面: ★6 5.1.1(ReMix)[73Another] 
リメイクした理由: 良い曲だったので
本体URL:http://web.archive.org/web/20070107082819/http://yoshinoya.dnsalias.com:8888/knm/2005_511.lzh
コメント:同梱N、I譜面と音ズレ無し　(※AfotherはA譜面と音ズレ無し)