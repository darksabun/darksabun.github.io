원본 패턴: ★3 88D [小さい]
재해석 패턴: ★15 88D [Oh!]
재해석한 이유: 노래가 마음에 들어 조금 더 고난이도로 만들어보았습니다.
본체 URL: https://dl.dropboxusercontent.com/s/y75i1xf7xdu1txc/88D.rar
이벤트 URL: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=99&event=93
기타 코멘트: 예전에 만든 어려운 차분보다 쉽게 만들었습니다, 추가 키음을 모두 같은 폴더에 넣어주세요.

原譜面: ★3 88D [小さい]
リメイク譜面: ★15 88D [Oh!]
リメイクした理由: 曲が気に入ってもう少し高難易度に作ってみました。
本体URL: https://dl.dropboxusercontent.com/s/y75i1xf7xdu1txc/88D.rar
イベントURL: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=99&event=93
コメント: 以前作った難しい差分より易しく作りました。追加音源をすべて同じフォルダに入れてください。

Original Chart: ★3 88D [小さい]
Reinterpreted chart: ★15 88D [Oh!]
Reason for reinterpretation: I liked the song, so I made it a bit more difficult.
BMS URL: https://dl.dropboxusercontent.com/s/y75i1xf7xdu1txc/88D.rar
Event URL: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=99&event=93
Other comments: I made it easier than the chart I made earlier. Put all the additional key-sounds in the same folder.