원본 패턴 : ★10 Little "Sister" Bitch
재해석 패턴 : ★9~10 Little "Sister" Bitch -Hope-
재해석한 이유 : 譜面はいいけど、トリルがすごく気になるので作りました
본체 URL : http://sunaneko.iptime.org/BMS_Library/Little%20%ef%bc%82Sister%ef%bc%82%20Bitch%20%28by%20t%2bpazolite%29.rar
기타 코멘트 : _little_sister_bitch_7_bga.bmeとズレなし、★10よりちょっと易い