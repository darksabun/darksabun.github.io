본체 IR : http://manbow.nothing.sh/event/event.cgi?action=More_def&num=28&event=61

원본 패턴 : ★1 Trump Is A Trump [ANOTHER]

재해석 패턴 : ★3 Trump Is A Trump [ABNORMAL]

재해석한 이유 : 49~56소절의 딜레이와 96소절의 3노트 계단은 입문 유저들에게는 저질스럽게 느껴질만하고
97소절부터 나오는 드럼 음원 부분도 언급된 두 구간에 비해서는 무난하지만 레벨 1에서 스크래치 처리하기에는 역시 곤란합니다.
노멀 게이지 이하로는 원본보다는 어려울수 있으나, 채보의 제목에 어울리게 비정상으로 짜봤습니다.

기타 코멘트 : AnzuTool 기준으로 49소절의 D8 키음 오류 현상이 있으나, 실제 SPA와 같은 음이 정상적으로 적용되어 있으므로 제안시 문제 없습니다.

