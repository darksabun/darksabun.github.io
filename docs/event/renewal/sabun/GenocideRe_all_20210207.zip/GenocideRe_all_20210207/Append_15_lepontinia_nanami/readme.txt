원본 패턴 : ★15 Lepontinia -THE LAST PLANET-
재해석 패턴 : ★21~22 Lepontinia -Despair & Hope-
재해석한 이유 : 私の古い差分を強化したかったから...
본체 URL : http://dl.dropbox.com/s/tspye2yzxlr69gd/prs_Lepontinia.rar
기타 코멘트 : lepontinia_7k_a.bmsとズレなし