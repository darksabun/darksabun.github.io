원본 패턴: ★9 A c i - L - A
재해석 패턴: ★9 A c i - L - W e i r D
재해석한 이유: 곡 분위기가 Weird Wave와 유사했기 때문에
본체 URL: http://malie.noor.jp/
기타 코멘트: 나는 차분을 짰다

原譜面: ★9 A c i - L - A
リメイク譜面: ★9 A c i - L - W e i r D
リメイクした理由: 曲の雰囲気がWeird Waveと似ていたので
本体URL: http://malie.noor.jp/
コメント: 私は差分を作った

Original Chart: ★9 A c i - L - A
Reinterpreted chart: ★9 A c i - L - W e i r D
Reason for reinterpretation: like Weird Wave
BMS URL: http://malie.noor.jp/
Other comments: I MADE CHART