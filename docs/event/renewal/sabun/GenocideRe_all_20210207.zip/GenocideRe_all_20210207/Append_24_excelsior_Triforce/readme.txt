원본 패턴	★24 キミとボクへの葬送歌 [Maybe kill]
재해석 패턴	★1 キミとボクへの葬送歌 [MINIMIZE]
본체 URL : http://manbow.nothing.sh/event/event.cgi?action=More_def&event=104&num=4

재해석한 이유
- 발광의 최고 레벨인 ★25를 최저 레벨인 ★1로 내려보자는 느낌으로 만들고자 했다. 하지만 ★25는 High-Priestess, FREEDOM DiVE 이외에는 없기에 ★25가 아닌 ★24에서 선정하게 되었다.

기타 코멘트
- exc_killlllllllllllll.bms와 엇갈림 없음.