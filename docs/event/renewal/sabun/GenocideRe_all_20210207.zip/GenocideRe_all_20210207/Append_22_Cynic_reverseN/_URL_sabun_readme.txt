원본 패턴: ★22 Cynic (THE another)
재해석 패턴: B5+ Cynic (THE DARKSABUN)
재해석한 이유: (^^)
본체 URL: https://web.archive.org/web/20060621033302/http://www.commonsense.nu/songs/cynic.zip
기타 코멘트: 나는 차분을 짰다

原譜面: ★22 Cynic (THE another)
リメイク譜面: B5+ Cynic (THE DARKSABUN)
リメイクした理由: (^^)
本体URL: https://web.archive.org/web/20060621033302/http://www.commonsense.nu/songs/cynic.zip
コメント: 私は差分を作った

Original Chart: ★22 Cynic (THE another)
Reinterpreted chart: B5+ Cynic (THE DARKSABUN)
Reason for reinterpretation: (^^)
BMS URL: https://web.archive.org/web/20060621033302/http://www.commonsense.nu/songs/cynic.zip
Other comments: I MADE CHART