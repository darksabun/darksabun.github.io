원본 패턴: ★9 スプラッシュコード－０６ [ANOTHER7]
재해석 패턴: ★19 スプラッシュコード－０６ [KF]
재해석한 이유: 스크 싫어
본체 URL: http://d11x.sakura.ne.jp/bms/curryyojo_Splashcode.rar
기타 코멘트: 나는 차분을 짰다

原譜面: ★9 スプラッシュコード－０６ [ANOTHER7]
リメイク譜面: ★19 スプラッシュコード－０６ [KF]
リメイクした理由: 皿嫌い
本体URL: http://d11x.sakura.ne.jp/bms/curryyojo_Splashcode.rar
コメント: 私は差分を作った

Original Chart: ★9 スプラッシュコード－０６ [ANOTHER7]
Reinterpreted chart: ★19 スプラッシュコード－０６ [KF]
Reason for reinterpretation: scratch suxx
BMS URL: http://d11x.sakura.ne.jp/bms/curryyojo_Splashcode.rar
Other comments: I MADE CHART