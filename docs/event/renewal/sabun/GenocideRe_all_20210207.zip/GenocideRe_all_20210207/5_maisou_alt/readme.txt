原譜面:★5 少女の舞葬
リメイク: ★4-5 少女の舞葬 [PARTY]
リメイク理由:これの物量譜面以外を見てみたい

本体URL:http://tm2.toymusical.net/download.html
	(http://www.mediafire.com/file/brtchuwqjvzn79p/%25E5%25B0%2591%25E5%25A5%25B3%25E3%2581%25AE%25E8%2588%259E%25E8%2591%25AC.zip/file)

コメント:同梱譜面03_maisou-h.bmeとズレがないことを確認済みです。




