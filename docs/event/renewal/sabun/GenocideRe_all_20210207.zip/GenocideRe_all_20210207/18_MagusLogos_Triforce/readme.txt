원본 패턴	★18 Magus Logos [HARD]
재해석 패턴	★18? Magus Logos [HARD Remastered]
재해석한 이유
- 원본 패턴이 상당히 재미있는 편이라고 생각한다. 다만, 스크래치의 사용이 너무 과도하게 어려운 경향이 있다고 생각하고 이것이 해당 차분의 하드게이지 클리어 난이도를 동 난이도에서 까다롭게 만들었다고 생각한다. 따라서, 스크래치를 일부 조정하고 곡 특유의 난이도적인 긴장감을 유지하는 패턴으로 수정해보았다.
본체 URL : http://nekokan.dyndns.info/~lobsak/bms/maguslogos_ogg.zip
기타 코멘트
- ★18 Magus Logos [HARD]와 엇갈림 없음.
- 내가 해봤을때는 ★18같았는데, 중반 이후 와장창이 역시 어렵긴 한듯.
- Triforce 차분 많이 욕해주세요