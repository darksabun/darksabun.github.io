CUTE-Mythology (ふわふわ)
本体：http://manbow.nothing.sh/event/event.cgi?action=More_def&num=468&event=133
想定難易度：sl6 (★11)