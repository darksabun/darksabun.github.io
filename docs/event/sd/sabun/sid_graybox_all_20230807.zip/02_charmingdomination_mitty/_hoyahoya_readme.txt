妖々跋扈 (ほやほや)
本体：http://yaritaihoudie.free.fr/bms/copy/th/bakko.zip
想定難易度：sl5 (★8)