Difficulty : sl12
Total : 741

Has additional key sound. so, some zure includes.

BMS URL : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=48&event=141