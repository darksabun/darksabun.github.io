Difficulty : sl3
total : 456

Well things happen maybe.