feeling派

bms by 空読無 白眼 : http://manbow.nothing.sh/event/event.cgi?action=More_def&num=20&event=133
sabun maker : used_tami
difficulty : ☆7
comment : 40분 만에 만들었습니다. (원 제작자님에 대한 리스펙트로 차분명은 없습니다)