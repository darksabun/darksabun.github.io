http://manbow.nothing.sh/event/event.cgi?action=More_def&num=365&event=133

LR2IR : http://www.dream-pro.info/~lavalse/LR2IR/search.cgi?mode=ranking&bmsid=292526

BPMを固定させて、ズレがあることがあります