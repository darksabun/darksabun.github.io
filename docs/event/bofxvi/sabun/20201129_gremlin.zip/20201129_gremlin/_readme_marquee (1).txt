본체URL : http://manbow.nothing.sh/event/event.cgi?action=More_def&num=382&event=133

추정 난이도 : ★22?

코멘트 : 안녕하세요. 게으른 자신을 반성하고자 차분을 만들었습니다.
stella급(★19~20 이상) 차분을 만드는건 많이 어렵네요.

엇갈림, 누락 없습니다. (gremlin_temp.bms 기준)