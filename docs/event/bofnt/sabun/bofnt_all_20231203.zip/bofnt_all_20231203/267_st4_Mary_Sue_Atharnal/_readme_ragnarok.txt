∀77∀H7∀Λ [RΛGИ∀ROK]
しるい / Mary_Sue + Atharnal
本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=267&event=142
推定レベル：★24?

_Defaultとズレ抜けなし。
よろしくお願いいたします。

작업하면서 재밌었습니다 (Atharnal)

そーなのかー(Mary_Sue)

Mary_Sue + Atharnal
2023/12/02