Get isekai'd
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=495&event=142