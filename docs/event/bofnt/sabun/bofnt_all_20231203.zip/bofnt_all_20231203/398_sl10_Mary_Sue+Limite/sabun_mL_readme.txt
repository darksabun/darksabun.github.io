Hello! My World!! [あの頃の僕らへ]
ああああ + 翡乃イスカ // Mary_sue + 幻の世界 feat.Limite

本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=398&event=142
推定レベル：sl10?
_.bmsとズレ抜けなし。

よろしくお願いいたします。
Mary_Sue (https://darksabun.github.io/Mary_Sue/) + Limite (https://www.limiteknj.net/BMS/)
2023/11/30