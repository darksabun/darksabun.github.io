Against the Destiny
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=98&event=142