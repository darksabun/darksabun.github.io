Song Link : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=88&event=142
Difficulty : sl6?
SPHとズレなし