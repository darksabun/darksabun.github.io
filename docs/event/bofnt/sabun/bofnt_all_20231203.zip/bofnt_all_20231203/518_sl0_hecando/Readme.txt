Vaelumir's Call

URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=518&event=142
Difficulty: sl0
_14a.bms と比較するとズレなし


BOF:NT差分企画: https://darksabun.github.io/event/bofnt/

-----------------------------------------------------------------------------------
本体をoggではなくwavでダウンロードしてください。 キー音が正常に聞こえません。
Please download the main body as a wav, not an ogg. The key does not sound normal.
본체를 ogg가 아닌 wav로 다운로드 해 주세요. 키음이 정상적으로 들리지 않습니다.
-----------------------------------------------------------------------------------