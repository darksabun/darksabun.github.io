difficulty: sl0~1 (★0~1)
song url: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=71&event=142