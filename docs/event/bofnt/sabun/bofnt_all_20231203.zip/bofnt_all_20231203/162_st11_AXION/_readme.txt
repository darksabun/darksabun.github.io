Raider - Armageddon to Archeopterix and Icaria 16
[DEATH] st11~12
obj: AXION

URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=162&event=142

BOF:NT差分企画: https://darksabun.github.io/event/bofnt/

:grieflash:
Included fixed 4_000.wav keysound for IR compatibility