Tekhfill [SP MARYTHER]
NIKANON (mov:DICE) / obj:Mary_Sue
本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=268&event=142
推定レベル：★23-24?
_temp.bmsとズレ抜けなし。
よろしくお願いいたします。

2023/10/30
Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)