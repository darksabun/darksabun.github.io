Nascent Terror

URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&event=142&num=61
Difficulty: sl4
_Nascent_Terror_7_4_A.bms と比較するとズレなし


BOF:NT差分企画: https://darksabun.github.io/event/bofnt/