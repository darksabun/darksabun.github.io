Typical Fate
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=361&event=142