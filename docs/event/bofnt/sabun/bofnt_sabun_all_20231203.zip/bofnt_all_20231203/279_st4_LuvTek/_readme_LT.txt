URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=279&event=142
Difficulty: st4 (★★3)
No misalignments compared to _infiniajourney_.null

BOF:NT差分企画: https://darksabun.github.io/event/bofnt/