口人間 [口回品]
空読無 白眼 / obj: Mary_Sue
本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=226&event=142
推定レベル：★23

_.bmmmmmとズレ抜けなし。
よろしくお願いいたします。

2023/11/20 
Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)