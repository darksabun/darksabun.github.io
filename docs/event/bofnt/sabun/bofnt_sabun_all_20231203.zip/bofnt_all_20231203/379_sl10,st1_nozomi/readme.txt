URL : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=379&event=142

comment : SPI基準ズレX, 七海さんの代わりで 立秋シリーズを続けてました。
NITROGEN : sl10?
SHRINKFLATION : st1?
