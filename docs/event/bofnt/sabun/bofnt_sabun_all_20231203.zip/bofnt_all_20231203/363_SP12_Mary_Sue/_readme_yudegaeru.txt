魔法でカエルになっちゃったみたい！ [茹でガエル]
sharkyo / obj: Mary_Sue

本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=363&event=142
推定レベル：★11-12?
_.bmsとズレ抜けなし。

よろしくお願いいたします。
Mary_Sue (https://darksabun.github.io/Mary_Sue/ or @MarySue_BMS)
2023/11/30