Crunk Rider
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=387&event=142