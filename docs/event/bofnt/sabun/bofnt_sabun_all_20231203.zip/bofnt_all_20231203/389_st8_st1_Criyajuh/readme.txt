nutty trip
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=389&event=142