2789Notes / Total:570 (0.2%/Note)
推定難易度:st0?

本体URL:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=496&event=142

同梱_Eiya_no_Cho_base.bmx基準ズレ抜けなし。ソフランなし。