URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=26&event=142
Difficulty: st3
No misalignments compared to _Dynasty_of_Extinction_0_2_multi.bms_

BOF:NT差分企画: https://darksabun.github.io/event/bofnt/