URL : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=168&event=142

Difficult : (ORACLE) sl1? (LIMBO) sl5?

comment : 이번에 Ponchi♪님 대타로 참가하신것을 노리고 3년동안 써먹었던 딜레이와 반대되는 동시치기 컨셉으로 비틀었습니다.

고민 끝에 HARD 판정으로 올리도록 하겠습니다
제목은 수녀님 그 곡 노린거면 맞지만 고성소 혹은 꼭대기라는 의미도 어느정도 담았으니 마음껏 즐겨주시기 바랍니다.

(12/02) 마감 50분만에 하위 채보 재빨리 올려봐요.