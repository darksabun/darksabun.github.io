Yamiyotake
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=284&event=142