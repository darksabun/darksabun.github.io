URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=238&event=142
Difficulty: st3
No misalignments compared to ikasama_template._bms

BOF:NT差分企画: https://darksabun.github.io/event/bofnt/