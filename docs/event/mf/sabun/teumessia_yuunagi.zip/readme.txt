difficulty: ★16~18
bms dl: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=87&event=127