URL: https://dropbox.bms.ms/u/53751238/Ino_BOFU2016_Natsuino_OGG.zip
Difficulty: ★15?
Comment:
* 検出されるズレについて
本譜面は同梱 Another 譜面を元に作成しています．
ズレチェックを行うと以下の3つの音でズレが検出されます．
  #WAV0D _Dr_pi_001.wav
  #WAV0J _Dr_Triangle_001.wav
  #WAVI8 G_Piano_bgm_-192.wav
このズレは上記のBGMとして使用されている音を本体に同梱されている音切り済みの音で置き換えているために発生しています．
実際に音ズレが発生しているわけではありません．
念の為上記の音を置き換えた未配置譜面を同梱します．(Natsuino_0note_sphere.bmx)