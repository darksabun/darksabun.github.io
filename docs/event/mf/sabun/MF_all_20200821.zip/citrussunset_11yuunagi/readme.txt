difficulty: ★1~2
bms dl: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=10&event=109