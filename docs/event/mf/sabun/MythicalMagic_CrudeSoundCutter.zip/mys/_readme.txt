﻿URL: http://web.archive.org/web/20040602232520/http://in-bpms.hp.infoseek.co.jp/Bmse/mys.lzh
Difficulty: ★23