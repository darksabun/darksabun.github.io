﻿Sabun Title: THOUGHTS BEFORE THE DEADLINE [TAKE CARE]
BMS DL: https://www.dropbox.com/scl/fi/f3f9etopmc9hzrwqdos2u/THOUGHTS-BEFORE-THE-DEADLINE.zip?rlkey=ozx3sc1ix3dxm2591x30q2b95&dl=0
Artist: kdcysth
Chart: Kurast703
Difficulty: sl2
BPM: 90
Removed #WAV43 Z.ogg
Because it is only used in specific bundled BMS and is longer than 1 minute
I finished this work before the DEADLINE xD