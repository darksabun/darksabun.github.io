レベルアッパー [Magic Sign] ★★1? (st1)
Artist: やまだぶりん /  https://venue.bmssearch.net/bmstukuru2025/82
-> 同梱SPIとズレなし。

風邪で締め切りに間に合わなかったせいで、バランスが少し取れていません ご参考ください。
