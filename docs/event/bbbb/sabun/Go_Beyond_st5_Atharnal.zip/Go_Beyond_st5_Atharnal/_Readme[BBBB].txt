超度 -Go Beyond-[BBBB]
Daily天利 (movie : 小鹏xpeng / Illust: Viosgit)
OBJ. Atharnal


本体 : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=105&event=142
推定レベル：St5


BPM : 240


ズレ チェック : 
 - ディレイキー音があるためよるズレあり
 - https://stairway.sakura.ne.jp/smalltools/minibmsplay/diff.htm では、ズレなし


よろしくお願いいたします。

-Atharnal (discord : Atharnal#2977)