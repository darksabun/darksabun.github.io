추가 키음을 전부 같은 폴더에 넣어주세요.
追加音源を全て同じフォルダに入れてください。
Please place all the additional audio files in the same folder as the BMS.

Title: amourazard (Challenge 4 LuvTek)

BMS by Orphex: 
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=102&event=104

Difficulty: B4-
BPM: 1200

Comment: 

이번에는 풀콤보 챌린지입니다. 
이지 클리어도 도전적인 난이도지만 파훼법은 있다고 생각합니다.
챌린지 성공 후에 남는 것이 희열일지 허탈함일지는, 플레이어 여러분도 함께 확인해주셨으면 합니다.

BPM 1200보다 빠른 BMS를 준비한 참가자 한 분 정도는 있지 않을까요?

今度はフルコンボチャレンジです。
イージークリアでも挑戦的な難易度ですが、攻略法はあると思います。
チャレンジを達成した後に残るのが喜びなのか、それとも虚しさなのかは、プレイヤーの皆さんにも一緒に確認していただきたいと思います。

BPM1200より速いBMSを準備した参加者が一人くらいはいるのではないでしょうか？

This time, it’s a Full Combo Challenge for LuvTek.
Even an easy clear would be a challenging difficulty, but there must be an ad-hoc strategy.
What remains after completing the challenge—whether it’s happiness or emptiness—is something I’d like all the players to experience and confirm for themselves.
