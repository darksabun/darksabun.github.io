Title: Quad Leg Pulverizer (With 3 ASSes mix) -Despair-
BMS by sd5y: https://www.bmsworld.nz/plugout4/
Difficulty: sl12
BPM: 480
Comment: FAST