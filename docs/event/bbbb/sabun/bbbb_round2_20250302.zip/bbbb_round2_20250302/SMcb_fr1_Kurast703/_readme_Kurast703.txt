Sabun Title: SpYCy MoS chEesE bUrgeR(Supertone refix)
BMS DL: https://venue.bmssearch.net/genreshuffle4/43
Artist: uet
Chart: Kurast703
Difficulty: fr1
BPM: 200000
This genre was proposed by me at GENRE-SHUFFLE4 =P
And this event is the perfect time to use it!
It's a HRHR option, but me had a lot of fun making this!