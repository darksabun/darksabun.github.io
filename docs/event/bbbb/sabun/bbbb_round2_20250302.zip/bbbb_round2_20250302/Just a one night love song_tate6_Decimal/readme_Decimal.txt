Title: Just a one night love song #Verticalized
BMS by カラフル・サウンズ・ポート:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=131&event=74
Difficulty: 縦6
BPM: 128
Artist: Decimal(深夜テンション)
Comment:
かなりの量の無音ノーツを使用しております。ご容赦ください。

この差分を作る動機がLONELY-MAZY [Timberman] の簡単ver欲しいな～、じゃあ作るか～。って感じのノリでした。
縦連の配置を決める無音ノーツを置いて、さあキー音に置き換えよう！とした時に、
置き換え可能なキー音が少ないことに気付いてしまいました。
もう深夜テンションで突っ切ることにしました。