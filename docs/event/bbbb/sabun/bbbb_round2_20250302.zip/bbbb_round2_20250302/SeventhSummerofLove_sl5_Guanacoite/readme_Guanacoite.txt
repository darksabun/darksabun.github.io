本体:http://mournfinale.com/bms/void_-_Seventh_Summer_of_Love.zip
14-Seventh_Summer_of_Love_[SPA]と比較してズレなし

BPM90 sl5

コメント: 大急ぎで作成 これかいてる時間もなし