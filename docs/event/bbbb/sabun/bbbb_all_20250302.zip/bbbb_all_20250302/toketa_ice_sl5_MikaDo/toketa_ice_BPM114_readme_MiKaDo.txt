Title：溶けたアイス、キミの声[大納言あずき]

BMS by kei_iwata feat.Noa (http://manbow.nothing.sh/event/event.cgi?action=More_def&num=403&event=133)

Difficulty:★8 sl5？

BPM:114

obj:MiKaDo

Comment:某アイス屋で大納言あずきを選ぶ人、見たことないです。同梱ANOTHERとズレなし。