本体:https://mega.nz/folder/FNFDCQaT#wfv-iI4UuSIaGpP0oFZdtQ/file/UFUjETpK

12-DJ_owllight_vs_xi-Aqua_Regia_Squall-7.bmeと比較してズレなし

BPM165 ★★5 Pollution, ★★6 Annihilation

コメント: いつか★12の強化版を作ろうと思ってたので作ってみました。
★24 P.S の練習譜面にしようと思ってたのに全くの別物になりました…。