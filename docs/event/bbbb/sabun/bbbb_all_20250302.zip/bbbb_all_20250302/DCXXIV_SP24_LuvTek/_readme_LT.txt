추가 키음을 전부 같은 폴더에 넣어주세요.
追加音源を全て同じフォルダに入れてください。
Please place all the additional audio files in the same folder as the BMS.

Title: DCXXIV [MMCD]

BMS by MIX-MAX: 
https://mega.nz/file/GDgFVR6K#DxBbmamVFC9QYgw4azvupjElEfnbPgxo9quHSJAEVno

(b.i.n.: https://web.archive.org/web/20221217171852/http://dot908.s17.xrea.com/bin2/?mode=detail&no=0488 )

Difficulty: ★24
BPM: 624

Comment: 

라운드 1에 비해 BPM을 절반 정도로 낮춘 안전주의 행보입니다.
그런데 패턴은 전혀 안전주의가 아니게 되었습니다. 여러모로 압도적인 패턴입니다.
패턴에 대한 아이디어 없이 곡부터 고르면 어떻게 되는지, 반면교사 정도로 기억되었으면 합니다.

第1ラウンドに比べて、BPMを半分ほど下げた安全主義のアプローチです。
しかし、譜面はまったく安全主義ではありません。様々な面で圧倒的な譜面です。
譜面のアイデアなしに曲を先に選ぶとどうなるのか、反面教師として参考にしてください。

This time, it's a cautious approach—lowering the BPM to about half compared to Round 1.
However, the chart is not cautious at all; every section is overwhelming.
Please take this as a lesson on what happens when you choose a song first without having any ideas for the chart.