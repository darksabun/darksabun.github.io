L -FINAL BOSS- ★20 (st0)
Artist: Ice / http://manbow.nothing.sh/event/event.cgi?action=More_def&num=146&event=83

（※追加音源あり）「LR2IR」対応のためカットされたBGMを借用しました。
SPAと比較して0.625~1節にズレが存在します、するには問題ありません。
容量の問題でwavファイルをoggに変換しました。 ご参考ください。
-> HQ version(wav): http://www.dream-pro.info/~lavalse/LR2IR/search.cgi?mode=ranking&bmsid=203336
Special thanks to Eiki. (@lapis_as_eiki)