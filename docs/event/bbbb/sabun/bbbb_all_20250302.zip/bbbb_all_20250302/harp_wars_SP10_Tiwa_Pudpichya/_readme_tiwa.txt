Title : Harp Wars Remix *4
BMS by SHK M-4r : https://mega.nz/file/W1NEGCiR#asuNCqZ7VdTTVkoKLpeLMmnh2_6yqgH3QZmQUf4mvCA
Difficulty: ★10?
Main BPM: 70 
Comment: harp wr.bms基準ズレ抜けなし

สวัสดี! ดีใจที่ได้เจอกันอีกนะ! เราชื่อ Tiwa Pudpichya!
เราได้รับคำขอจาก Mary_Sue ให้สร้างแพทเทิร์นจากเพลงที่มีจังหวะช้าๆ
นี่เป็นเพลงของคุณ SHK นักแต่งเพลงชื่อดังจากเกาหลี
แต่เราเปลี่ยนไปนิดหน่อยเพื่อเพิ่มความยากขึ้นนิดนึง
ขอให้สนุกนะ! 😊