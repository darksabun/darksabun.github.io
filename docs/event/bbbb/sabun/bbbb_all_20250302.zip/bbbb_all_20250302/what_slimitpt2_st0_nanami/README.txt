Title: What's Limit?? Pt.2 -Hopeless-
BMS by sd5y: https://www.dropbox.com/s/uqt7iskyh812kms/Whats_Limit_pt2.rar?dl=0
Difficulty: st0
BPM: 600
Comment: FAST
