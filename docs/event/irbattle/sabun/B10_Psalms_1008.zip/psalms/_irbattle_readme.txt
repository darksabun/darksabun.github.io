https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

本体URL 
http://manbow.nothing.sh/event/event.cgi?action=More_def&event=133&num=128
[ 中級者IR（カーテン）]
推定難易度: ◆17

Point expression 
100 * (score - 12 / 18) / (5 / 18)
A(66.67%) = 0
AA(77.78%) = 40
AAA(88.89%) = 80
MAX-(94.44%) = 100

Comment
_Psalms_0とズレチェック済み。
もっとLN譜面を。
