https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

本体URL 
http://uploader.bms.ms/data/bof2009/kenkyo/ritsu06_hverfa_ogg.zip
[(^^)IR（総合力）]
推定難易度: st9 (★★5)

Point expression 
min(100, [0,20,30,40][min(clear,3)]+max(0, (200-BP)/4)+25*(EXscore/(2*totalNotes)))

Comment
追加音源によるズレあり
2021년 3월에 완성했지만, 난이도가 너무 높아 공개를 보류한 차분입니다.
이지 난이도는 st9 Prog-M보다 높은 것 같지만 그래도 st9로 추정합니다.
클리어 될 것 같은데 안되네