https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

本体URL 
https://1drv.ms/f/s!AsmoDHSAppX8gYp5ivi_0xYFitL2Hw
クレクレ板まとめ → 改pt.1 → 284.zip → bjc5 → FOL-HQ.zip, fol_bga.zip

or

https://mega.nz/file/GK4WhI6Z#FiuxYQXTFu5cct0rhMdcLjFrVMO38vNKOfgB8UtbhGo

[上級者IR（スクラッチ）]
推定難易度:★19-20

Point expression 
min(100, [0,5,15,30][min(clear,3)]+max(0, (90-BP)/3)+50*(EXscore/(2*totalNotes)))

Comment
追加音源によるズレあり
Not respect for Rainy Heart -IR-