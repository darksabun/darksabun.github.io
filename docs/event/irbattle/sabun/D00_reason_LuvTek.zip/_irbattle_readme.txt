https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

本体URL 
http://web.archive.org/web/20040411171700/http://in-bpms.hp.infoseek.co.jp:80/BMS2.htm
[(^^)IR（主催）]
推定難易度: st8?

Point expression 
min(100, [0,20,30,40][min(clear,3)]+max(0, (250-BP)/5)+25*(socre/2*totalNotes))

Comment
beyond the reason