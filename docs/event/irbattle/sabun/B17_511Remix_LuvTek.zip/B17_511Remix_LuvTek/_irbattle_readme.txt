https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

本体URL 
http://wayback.archive.org/web/20090309205500/http://knm.sakura.ne.jp/pms/index.html
[中級者IR（カオス）]
推定難易度: B-1?

Point expression 
min( 100, [0,20,30,60][min(clear,3)]+max(0, (144-BP)/4)+10*(EXscore/(2*totalNotes)) )

Comment
과거에 만들었던 5키 차분을 재해석한 것으로, Genocide Reinterpretation에 제출하려 했던 패턴입니다.
원래는 카오스 태그를 제안하면서, 카오스 태그의 최상급자 차분을 제작하려 했으나, 중급자로 변경해 IR Battle에 제출하게 되었습니다.