LR2IR BATTLE : https://darksabun.github.io/event/irbattle/

http://web.archive.org/web/20041204023702/http://www.rinku.zaq.ne.jp/makky/pro.zip
中級者IR (ズレ)
sl4~5?
78%以下=40点 / 78~82%=50点 / 82~86%=60点 /
86~90%=70点 / 90~94%=80点 / 94%以上=90点 /
フルコン=10点追加
(最小40点, 最大100点)
曲がすごい
#44~#49のズレはキー音を追加したものなので問題なし

08/06
1ms以下のズレがありますが、問題はなし
