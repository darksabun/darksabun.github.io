SONG URL : http://manbow.nothing.sh/event/event.cgi?action=More_def&num=120&event=127
TAG : CHAOS
推定レベル：★23?
POINT : [{90*(SCORE/3000)}+2.5(FAILED) or 5(EASY CLEAR) or 7.5(GROOVE CLEAR) or 10(HARD CLEAR)]
COMMENT : 曲名長いな…

__empty.bms基準ズレ抜けなし。