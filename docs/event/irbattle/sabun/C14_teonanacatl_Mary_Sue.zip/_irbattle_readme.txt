SONG URL : https://spirea3cross.wixsite.com/citadel/teonanacatl
TAG : やさしいソフラン
推定レベル：★24
POINT : [{60*(SCORE/4770)}+10(FAILED) or 20(EASY CLEAR) or 30(GROOVE CLEAR) or 40(HARD CLEAR)]
COMMENT : Too late

2_teonanacatl.bms基準、検出されるズレは全部ソフラン関連のズレなのでプレーには問題なし。