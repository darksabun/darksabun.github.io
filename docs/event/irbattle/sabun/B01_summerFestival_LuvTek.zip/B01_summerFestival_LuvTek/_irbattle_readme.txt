https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

本体URL 
https://web.archive.org/web/20040630162229/http://www.ismusic.ne.jp/qurter/sound/summer%20festival.rar
[中級者IR（微連打）]
推定難易度: ★14?

Point expression 
min(30, clear*10)+max(0, (200-BP)/10)+30*(EXscore/(2*totalNotes))+20*(maxCombo/totalNotes)
Therefore, for clear: failed 0pts, EC 10pts, GC 20pts, HC 30pts

Comment
追加音源によるズレあり
Recommended for 微連打入門
잡연타 입문 느낌으로 만든 패턴입니다.
제가 준비한 summer festival인 이 이벤트를 모두들 즐겨주셨으면 합니다.