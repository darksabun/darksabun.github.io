SONG URL : https://dropbox.bms.ms/u/60346274/Neunjack/Convalla_ogg.zip
TAG : ズレ
推定レベル：★25
POINT : [{90*(SCORE/10706)}+0(FAILED) or 1(EASY CLEAR) or 5(GROOVE CLEAR) or 10(HARD CLEAR)]
COMMENT : 運動になる易しい譜面ですわ

Convalla_bass.bms基準ズレ抜けなし。