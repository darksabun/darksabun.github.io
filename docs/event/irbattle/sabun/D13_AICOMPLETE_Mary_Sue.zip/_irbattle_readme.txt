SONG URL : http://manbow.nothing.sh/event/event.cgi?action=More_def&num=34&event=84
TAG : DARKSABUN
推定レベル：★21? (★25以上かもしれません）
POINT : [{10*(EX-SCORE/6060)} + 0 (FAILED) or 90 (EASY CLEAR or GROOVE CLEAR or HARD CLEAR or FULL COMBO)] 
COMMENT : なんと百番目の譜面だよ！今までありがとうございました！これからもよろしくお願いします！

_aiko_04_another7.bme 基準ズレ抜けなし。