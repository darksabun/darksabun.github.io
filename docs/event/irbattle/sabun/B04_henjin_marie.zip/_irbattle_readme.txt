��15 �ϐl�X�`���̒��Ƀ`�F�[�����L����` -IR-

�{��: https://www.axfc.net/u/3935926?key=bms

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

bp_bonus = 20 / (21 + bp)

score_bonus = (0.5 * ex_score / notecount)^2.5

score = 100 * (bp_bonus + score_bonus - score_bonus * bp_bonus)

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The less BP you have the less ex score matters, but 100% ex score will always give you 100 points so try to optimise both!

This was pretty tricky to chart as I'm always unsure about how to do low level gachi.