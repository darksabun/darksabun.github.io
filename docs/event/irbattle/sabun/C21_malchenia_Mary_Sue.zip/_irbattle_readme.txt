SONG URL : http://leafbms.web.fc2.com/song.html
TAG : 低BPM
推定レベル：★23-24?
POINT : [{60*(SCORE/5,984)}+10(FAILED) or 20(EASY CLEAR) or 30(HARD CLEAR) or 40(GROOVE CLEAR)]
COMMENT : 終盤が一番易しいのでGROOVE GUAGEおすすめ

_insane_7key.bms基準ズレ抜けなし。 