https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

本体URL 
https://drive.google.com/open?id=1e7qn38WEloRhhIatg5vPbSEabWVKrquW
[(^^)IR（超長尺）]
推定難易度:B6

Point expression 
[0,25,36,81][min(clear,3)]+max(0, 25*(totalnotes-BP)/totalnotes)

Comment
アレンジ差分
It will take a very long time to load the chart, so be careful.
Your bus travels Tucson to Las Vegas at 40-45 mph and it is marked with BPM.
The distance is 360 miles, and a measure corresponds to one mile.
For simplicity, all the FX sounds are removed, but the title screen of Crazy Bus will be with you.