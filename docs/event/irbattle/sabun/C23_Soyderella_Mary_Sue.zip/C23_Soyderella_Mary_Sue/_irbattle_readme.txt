Song URL : https://venue.bmssearch.net/3/20?event=3&id=20
TAG : 長尺
推定レベル：★24?
POINT : [{60*(SCORE/8822)}+10(FAILED) or 20(EASY CLEAR) or 30(GROOVE CLEAR) or 40(HARD CLEAR)]
COMMENT : えび！ばてぃ！せい！ソイ！！https://soundcloud.com/master223-0p/to-nyu-power　←必聴

_To-Nyu_AAACup.bms基準ズレ抜けなし。