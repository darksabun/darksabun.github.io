https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

Song URL : http://manbow.nothing.sh/event/event.cgi?action=More_def&num=249&event=127
Difficulty : ★17?

Point expression
하드 클리어 20점 / 노멀 클리어 16점 / 이지 클리어 10점
Rank A의 숫자에 따라 10점씩 추가 (최대 30점)
퍼센티지에 따라 점수 반영 (최대 50점, 만일 90%일 경우 45점 부여한다)

Comment 
110번 구간에 킥에 맞춰 키음이 한개 추가된것 이외에는 즈레 X (SPA 기준)

노트수도 푸나이, 토탈치도 푸나이 (노트수도 2271, 토탈치도 271)

원래는 저토탈 항목에 있어야 했던 패턴이지만, 편의성으로 인해 고BPM로 통합하였습니다.

"딱 271이다. 371,471 그런거 없다."

