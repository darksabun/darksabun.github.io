|=-------------------------=|
|=---[ ironic sea -IR- ]---=|
|=-=-=-=-=-=-=-=-=-=-=-=-=-=|
|=------[ fkRadish ]-------=|
|=-[ C11 ]---[ obj. sera ]-=|
|=-------------------------=|

--[ URL

https://beatmaniauet.wixsite.com/kusekorebmspack2020

--[ TAG

2키/2鍵/2Keys

--[ Estimated difficulty

21..........???

--[ Point expression

math.log(exscore+1)*60/math.log(1954)+lamp*5+15*(max_combo/977)

--[ Comments

A lazy chart? GOOD luck