For LR2IR BATTLE
https://darksabun.github.io/event/irbattle/

Music Download: http://web.archive.org/web/20120507144453/http://youzyo.net/bms/ama03_kakumo.zip

C02 - �㋉��IR�i�A�ŕ����j
��22~23 / st3~4? (personal opinion is ��23, but for EC it might be ��22)

Uses Another chart as base, but replaces #WAV0A / #WAV0B (d_hhl.wav) with quantized hi-hat loop samples found in #048~#055
No additional misalignments (hopefully, double checked with AnzuBMSDiff but there might be more...)

Point Expression formula:
min(max(40-misscount,0),30) + clearlamp*4 + (exscore/maxnotes)*10 + max((max(maxcombo-100,0)/100.)*6,30)

-------------------------------------------------

It was shone on in the skies... that...
beautiful bright scarlet moon,
and one girl kept seeing the fate of the eternity and
this world that was able to be said.

I usually attacked it.
However, you previously attacked it.
You are crazy.

Though the moon is bright red so.
A happy night might come.
A long night might come.

Well...
The cooking method that
easily removes All of life material...

Luna Dial :
Your time is mine...
An antique watch doesn't have the winning(?)
Choose

Only human
Needing a brain sample scientific idea comes(?)
Human is interested, but aren't you human?