��0 Hypertext Transfer Protocol -418-

�{��: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=353&event=83
zure check: http_spn.bme

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

bp_penalty = 10 - 100 / (10 + bp)

score = (50 * ex / notecount) - bp_penalty 

if score < 0 then default to 0

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

I wanted to make a fairly straight forward chart, yet still challenging in
its own way. The polyrhythms in this song lend themselves to hard judge
very well I think!