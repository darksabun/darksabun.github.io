https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

本体URL 
https://1drv.ms/u/s!AkHILFwfHSyzgQ4rrP7WIsDKU3Og

[ (^^)IR（カオス）]
推定難易度: ★★7

Point expression 
max(0, 250 - BP / 5)

BP 1250 = 0
BP 1000 = 50
BP 750  = 100

Comment
_hoshikuzu_apotosis_7mon.bms(差分)基準
申し訳ございませんが、これは悪いネタ譜面です。
