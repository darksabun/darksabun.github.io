LR2IR BATTLE : https://darksabun.github.io/event/irbattle/
본체 URL : https://dropbox.com/s/1x13o0mh5yjnwo8/hoshi_no_oujisama_ogg.zip?dl=1
차분의 태그 : NORMAL GUDGE, 연타, 순간발광
추정난이도 : ★8 / sl5
포인트 식 : { [ (SCORE) ÷ 3264 ] × 100 } - (BP)
코멘트 : 연타 1라인에 다른 노트가 섞여나오는 까다로운 패턴을 NORMAL판정으로 얼마나 잘 처리할 수 있는지 확인할 수 있습니다. 순간발광적인 요소가 강해, BP의 카운트가 높게 들어갑니다.