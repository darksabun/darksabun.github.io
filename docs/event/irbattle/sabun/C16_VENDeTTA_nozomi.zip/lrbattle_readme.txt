https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

Song URL : http://starkey.ivory.ne.jp/mf/mf2/detail/view/21/
Difficulty : ★22?

Point expression
Rank A시 10점 / AA시 20점 / AAA시 30점
B+P 22이하 30점 / B+P 44이하 25점 / B+P 66이하 20점 / B+P 88이하 15점 / B+P 88이상 10점 
하드 클리어 15점 / 노멀 게이지 13점 / 이지 클리어 10점
콤보 퍼센트 기준에 따라 최대 25점까지 적용 (예를 들어 2400 콤보일 경우, 25 / 4 = 6.25 x 3 = 18.75점 적용) 

Comment 
SPI 기준 일그러짐 X

난타+동시치기+폴라리듬+12비트 끊어치기+후살+알약

sl11 INSANE과 st7의 Alterego의 지나친 차이를 막기 위해 추가된 패턴입니다.

"모두 빈첸초(정복자)가 되어서, 스텔라의 개인차를 척결하자!!"
