https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

Song URL 
http://manbow.nothing.sh/event/event.cgi?action=More_def&num=6&event=123
[中級者IR（総合力）]

Difficulty : ★10

Point expression
콤보 점수 (Max 40pts)
0 = 0pts
1~458 = 8pts
459~917 = 16pts
918~1376 = 24pts
1377~1835 = 32pts
1836~2294 = 40pts

레이트 점수 (Max 60pts)
~74.99% = 10pts
75~79.99% = 20pts
80~84.99% = 30pts
85~89.99% = 40pts
90~94.99% = 50pts
95~100% = 60pts

Comment
난타, 동시치기, 짧은 연타, 스크래치 등 여러가지 요소가 담겨있습니다.

엇갈림 없음 ([0]blank 기준)