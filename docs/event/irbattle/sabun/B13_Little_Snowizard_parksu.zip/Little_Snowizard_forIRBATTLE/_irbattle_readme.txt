https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

本体URL 
https://yosk.ojaru.jp/bmsyosk2.html#104
[ 中級者IR（DARKSABUN）]
推定難易度: B-3

Point expression 
min(100, (10**(clear-1)-0.1)+50*rate)

Comment
元々はスイングでした…