https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

本体URL 
https://onedrive.live.com/?id=FC95A680740CA8C9%21111&cid=FC95A680740CA8C9
[ 上級者IR（キー音アレンジ）]
推定難易度: ★21?

Point expression 
4*math.log2(min(combo+1,1024)) * 2.5**max(0,min(1,((combo/1024)-1)))

Comment
Re-Factory
Put all additional key-sounds and bmp file in the same folder.