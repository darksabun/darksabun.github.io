https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

本体URL 
https://mega.nz/file/QfwzgABZ#MJ3z2RcCKlcQIOihargB195MZwZy90j5FuJsCRwgAXw
[ 中級者IR（Battle）]
推定難易度: ★15?

Point expression 
100*rate

Comment
https://www.youtube.com/watch?v=G-FdX1D5hVg <- JUST WATCH
ズレは意図的です。