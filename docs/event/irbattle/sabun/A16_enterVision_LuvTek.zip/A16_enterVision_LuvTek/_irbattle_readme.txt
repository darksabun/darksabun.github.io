https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

本体URL 
http://web.archive.org/web/20030609231459if_/http://careless.hp.infoseek.co.jp:80/e_vision.rar
[初級者IR（総合力）]
推定難易度: ★8

Point expression 
min(100, 5*(combo/totalNotes)+max(0, (100-BP)/2)+50*(EXscore/(2*totalNotes)))

Comment
追加音源によるズレあり
난타, 연타, 트릴, 고속계단의 종합력 차분입니다.
초급자를 위한 차분인지는 잘 모르겠습니다.