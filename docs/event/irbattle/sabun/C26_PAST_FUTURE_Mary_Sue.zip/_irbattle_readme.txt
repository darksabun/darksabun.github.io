SONG URL : http://www.mediafire.com/file/wvuid5ysju1eyou/Percussion_Battle.zip/file
TAG : Battle
推定レベル：★24?
POINT : [{60*(SCORE/6262)}+10(FAILED) or 20(EASY CLEAR) or 30(GROOVE CLEAR) or 40(HARD CLEAR)]
COMMENT : これが、一次元。

Percussion_Battle.bms基準ズレ抜けなし。