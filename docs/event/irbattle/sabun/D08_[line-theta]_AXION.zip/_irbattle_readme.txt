LR2IR BATTLE event page: https://darksabun.github.io/event/irbattle/
本体URL: https://www.dropbox.com/s/1wbit5p08wqyxmm/%5Bline%EF%BC%9Atheta%5D%20%28by%20nitro%29.rar?dl=0
イベントURL: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=255&event=123

★★4~5?
Point expression: (score / total_notes * 100)

No misalignment with included template file
Additional blank scratch notes have been added to simulate BSS on some parts (measure #067 and #071, keysound ZW)

NOW LET ME SEE YOU
for scratch + chordstream enthousiasts