|=-------------------------=|
|=---[ Fire eyes  -IR- ]---=|
|=-=-=-=-=-=-=-=-=-=-=-=-=-=|
|=---------[ Rai ]---------=|
|=-[ A10 ]---[ obj. sera ]-=|
|=-------------------------=|

--[ URL

https://drive.google.com/file/d/1uqFhiYDHC58VyucZP-OjQKsBoW2z4ego/view?usp=sharing

--[ TAG

커튼/カーテン/Curtain LN

--[ Estimated difficulty

◆11

--[ Point expression

max(0,exscore/12.125+lamp*5-bp/2)

--[ Comments

A somewhat straightforward curtain chart with strong hand bias. Cruel for BM. Beware the scratches!