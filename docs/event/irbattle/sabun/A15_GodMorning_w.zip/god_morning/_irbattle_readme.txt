Title: God Morning -Another mix- [皿-LN-W]

Obj: w

本体/Song URL: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=305&event=133

タグ/Tag: A15 初級者（バラエティ）

推定難易度/Estimated Difficulty: ★7

Zure check: God Morning_ANOTHER.nullbms 
    (SHIFT ALL NOTES UP BY 1 MEASURE, SO SONG STARTS AT MEASURE 1)

ポイント式/Point Expression (PYTHON): 
```python
# clear: 0=FAILED, 1=EASY, 2=NORMAL, 3=HARD, 4=FULLCOMBO, 5=PERFECT
# ex_score//(total_notes*2): score rate

def point_function(clear, ex_score, total_notes):
    return min(100,  
        [0,5,15,30,40,40][clear] +
        max(0, 2*int(100*ex_score/(total_notes*2) - 65))
    )
```

ポイント説明/Point Explanation:

# CLEAR (max 40pts)
>=EASY: +5
>=NORMAL: +10
>=HARD: +15
>=FULLCOMBO: +10

# SCORE RATE (max 70pts)
 2 * ( (score rate * 100) - 65pts )
<=65% = 0 pts
70% = 10 pts
75% = 20 pts
80% = 30 pts
85% = 40 pts
90% = 50 pts
95% = 60 pts
100% = 70 pts
(e.g. 53% = 0pts, 92% = 54 pts)

FULLCOMBO + 95% = 100pts

-------------------
Comment: 

Recommend MAX BPM FIX

The "variety" tag is quite straightforward to understand. It's what I like to do - have many different elements in my charts, like LN, scratch and jacks. I find that many of my recent charts would satisfy the "Variety" requirement.

God Morning - Jacks, Scratch, Soflan, LN
Gimme All The Cocaine - Scratch, Soflan, LN, Long Trill
THz - Jacks, Scratch, LN

Because my charts usually satisfy the "variety" requirement, it didn't feel like I really did anything special for this chart. It just feels like what I would normally do. I tried to add more LN and scratch than usual though. It has plenty of LN and scratch, but I don't know if it really has enough to qualify as an LN chart, or a 皿 chart. It's just... in the middle of everything, so I'm not really sure what this chart is for.

It seems like many BMS patterns focus only on chordstreams and chords (and sometimes jacks and zure). There is a tendency to remove "unique" patterns like LN and scratch when making a sabun from a default chart, which can make a song lose part of what makes it interesting. I think this charting meta creates a playerbase with unbalanced skillsets - strong at density, weak at everything else (scratch, LN, trills, soflan etc). I wish modern tables would contain more charts that are good for practicing varied skill sets.

I tried experimenting with some LN + scratch patterns in this song. They are quite tricky to make, because they have the potential to form unreachable patterns. My main trick is to keep LNs short, and try to put LNs between, not during scratches. I think the LNs give the effect of "jumping" your hand between the keys and the turntable.

Another idea I experiment with here is the "low scroll speed BSS" section. When playing a BSS note on a controller, the player only has one hand to play all seven keys. Most players are not good with playing complex patterns with only one hand. My experiment here is to make a 1-handed pattern, but at a low scroll speed (105bpm = 60% scroll) in measure #80-81. A slower scroll speed should give an inexperienced one-hand player more time to prepare.

One pattern I used twice in this chart is the "fast scratch + trill" burst pattern (measures #55, #97). I personally find this pattern fun and tricky to do, and previously used it in my S≠M [BUNNY EXTINCTION] chart. I think many people may not like this pattern though, because it is difficult to play. I like the pattern, so I decided to keep it.

This was the first chart I made for IR battle, but I wasn't satisfied with it, and just left it there to slowly make adjustments over the past four weeks.
Overall, I think this was an okay chart. I think I could have done better, because this is such a good, varied and interesting song.


-------------------

IR BATTLE: https://darksabun.github.io/event/irbattle/

Website:https://wcko87.github.io/
Twitter:https://twitter.com/wcko87
自作譜面の難易度表:https://wcko87.github.io/bms-table/obj-w.html