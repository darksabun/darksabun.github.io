LR2IR BATTLE : https://darksabun.github.io/event/irbattle/
본체 URL : https://drive.google.com/file/d/1oF6NjrPjQaF13vt__eq6okLrNPcYgvm_/view?usp=sharing
차분의 태그 : 후살, NORMAL GUDGE, 딜레이
추정난이도 : ★24 / st7
포인트 식 : { [ (SCORE) ÷ 5440 ] × 100 } - [ (BP) × 0.3 ]
코멘트 : 초보자용 판정연습 고BPM 폭타곡을 만들려고 하다가 고수도 판정연습 못한 고BPM 32비트 딜레이가 나왔습니다. 난몰라 알아서해