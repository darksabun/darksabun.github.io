LR2IR BATTLE Event Page:
https://darksabun.github.io/event/irbattle/
Difficulty/難易度:  (^^)IR HARD判定
★★4?
本体URL:
http://malie.noor.jp/
http://malie.noor.jp/archive/aci-L.rar

Point expression:
(score / totalnotes) * 90 + (ln(max combo) / ln(totalnotes)) * 10 
min score:
0
max score:
100

- 4 5 ?