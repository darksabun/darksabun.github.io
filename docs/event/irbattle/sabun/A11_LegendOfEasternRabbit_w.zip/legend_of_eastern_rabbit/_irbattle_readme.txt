Title: Legend of Eastern Rabbit -SKY DEFENDER- [2KEYS]

Obj: w

本体/Song URL: http://k-bms.com/party_pabat/party.jsp?board_num=20&num=2

タグ/Tag: A11 初級者（2鍵）

推定難易度/Estimated Difficulty: ★8

Zure check: TUD_7KSHD.bms

ポイント式/Point Expression (PYTHON): 
```python
# clear: 0=FAILED, 1=EASY, 2=NORMAL, 3=HARD, 4=FULLCOMBO, 5=PERFECT
# 9*ex_score//(total_notes*2): 5=B, 6=A, 7=AA, 8=AAA, 9=MAX

def point_function(clear, ex_score, total_notes, is_not_sran):
    return ( 
        [0,10,20,40,55,55][clear] +
        [0,0,0,0,0,10,20,40,45,45][9*ex_score//(total_notes*2)]
    ) if is_not_sran else 0
```

ポイント説明/Point Explanation:

[WARNING] Playing on S-RAN gives you 0 points. If you played on S-RAN, type /deletescore in LR2's search box to delete your score.

!!注意
S-RAN をかけるとポイントが 0 点になってしまいます。気をつけてください。
万が一 S-RAN をかけてしまった場合は LR2 の選曲画面の検索欄に /deletescore を入力することでスコアを削除することができます。

# CLEAR
>=EASY: +10
>=NORMAL: +10
>=HARD: +20
>=FULLCOMBO: +15

# GRADE
>=B: +10
>=A: +10
>=AA: +20
>=AAA: +5

-------------------
Comment: 

The 2KEYS tag was inspired by 甘でラッシュ！ by U咲 in BOFU2016. This entry had the standard N/H/A charts, plus a [2KEYS] chart. I played the 2KEYS chart out of curiosity, and it turned out to be the most fun default chart for the song. 

Setting constraints fosters creativity. I've always wanted to try this for myself, to see whether I could make an interesting chart using only two keys. After all, 甘でラッシュ！ could do it, Muse Dash could do it. I think 2KEYS charts are fun because the player can focus their index fingers to jack the two keys (it is easier to enjoy jacks when there is no worry about other lanes). I found that my most stable stance is to join my index and middle fingers to press the button together.

It seems like the most suitable songs for 2KEYS charts are songs that are relatively fast, and have complex/varied rhythms. The Legend of Eastern Rabbit is one of my favorite songs from PABAT!2020. It's fast, exciting, has crazy rhythms, and I absolutely love the BGA. It is extremely fun to listen to and play. I was excited when this song was introduced to Muse Dash, but they used a cut version of the song which removed many of the exciting parts. I think the BMS version is much better.

I think the fast rhythms in the background (from the oriental string instrument I can't identify) could make for some very fun jacks. I was considering making a sabun for it, but DK made one (★7) before I could. The chart was fun, though it didn't have as many jacks as I hoped.

With 2KEYS, the patterns I have to work with are basically jacks, trills and LNs. Most of the difficulty will have to come from jacks, which is perfect for this song. Oriental string instrument = jacks, fast guitar = trills, long guitar = LNs.

With two lanes, I have two options to make patterns:
1. Use both lanes to represent one instrument
2. Put a different instrument on each lane
The chart is tricky to make because I can only represent one or two instruments at a time. More instrumentally complex sections will have to be simplified, by choosing which instrument I want to focus on.
If I want to make a trill (e.g. fast guitar), I have to use both lanes for this one instrument. If I am making jacks, I can use one instrument on each lane. So jacks are much easier to make than trills.

I think using Long Notes is good for emphasising the more prominent guitar sounds. However, using a long note means I only have one lane left for the other instrument. I can do LN+jack, but I don't have enough lanes for LN+trill, so it is difficult to chart patterns which are long guitar + fast guitar.

One more thing I did was include jacks in my trills to make the trills more interesting (e.g. 17117111771 instead of 17171717171). I listened to each of the fast guitar riffs individually, figure out how I could mix in jacks into the pattern. For example, in a melody, a note can have a higher or lower pitch than the previous. If we decrease in pitch twice in a row, I might make it a jack. If it switches from decreasing to increasing, I switch to the other lane.

Hopefully I have made a chart that is fun to play and represents the music well.

Time spent: ~1-2 weeks

-------------------

IR BATTLE: https://darksabun.github.io/event/irbattle/

Website: https://wcko87.github.io/
Twitter: https://twitter.com/wcko87
自作譜面の難易度表: https://wcko87.github.io/bms-table/obj-w.html