SONG URL : https://web.archive.org/web/20140409113519/http://www.geocities.jp/yuzuru0024/BMS/ori02.zip
TAG : VERYHARD判定
推定レベル：？？？
POINT : [{60*(SCORE/2842)}+10(FAILED) or 20(EASY CLEAR) or 30(GROOVE CLEAR) or 40(HARD CLEAR)]
COMMENT : TOTALが高いのでVERYHARD判定の差分としては入門レベルかなぁ

child(A).bms基準ズレ抜けなし。