https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

本体URL 
https://drive.google.com/file/d/16mo8K6LzlxE8WOStr44rCjdtNqVvnvZG/view

[ 初級者IR（超長尺）]
推定難易度: ★8(理想)、★12～★14(現実)

Point expression 
min(maxcombo / 40, 100)

Comment
追加音源有り。曲変更なのでズレチェック不可。
フル尺はこちら（https://www.nicovideo.jp/watch/sm14724683）を参考に作りました。
そもそも差分もほとんど無い曲ですが、差分が作られることを願って、あえて、フル尺で作ってみました。
同梱譜面からコンボカッター満載なので、マックスコンボ勝負な譜面にしてみました。

0notes譜面も同梱しています。使いたい方はご自由にお使いください。
