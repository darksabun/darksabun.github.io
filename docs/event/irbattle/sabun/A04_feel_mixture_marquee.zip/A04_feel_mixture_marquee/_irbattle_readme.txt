https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

Song URL 
https://docs.google.com/spreadsheets/d/1lO2z7KVYyMpE-SjFwEEtvCwQhadl9Kgoqge_j2wsUPI/edit#gid=0
[初級者IR（ガチ押し）]

Difficulty : ★3

Point expression
기본 점수
EXSCORE÷35.7 (소수점 반올림했을 시 최대 95pts)

추가 점수
FULLCOMBO +3pts
★FULLCOMBO +5pts

Comment
느린 끊어치기를 만들어 보았습니다. ★2 夜明けの少女たち [Another+]랑 비슷한 느낌입니다.

엇갈림 없음 (_feelmixture_7n.bme 기준)