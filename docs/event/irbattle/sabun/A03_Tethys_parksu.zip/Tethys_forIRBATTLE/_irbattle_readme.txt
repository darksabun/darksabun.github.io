https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

本体URL 
http://scytheleg.sakura.ne.jp/tempyou/bms/bms/Tethys.rar
[ 初級者IR（縦連打）]
推定難易度: ★1

Point expression 
100*score/3860

Comment
I LUV LONG-JACKS!