LR2IR BATTLE : https://darksabun.github.io/event/irbattle/

http://tm2.toymusical.net/download.html
上級者IR (ズレ)
st2~3?
40点-BP
82%以下=30点 / 82~86%=40点 / 86~90%=50点 / 90%以上=60点
(最小30点, 最大100点)
曲がすごい！
#49から曲を節を追加したのでズレがあります(問題はなし)

07/19
差分を強化しました