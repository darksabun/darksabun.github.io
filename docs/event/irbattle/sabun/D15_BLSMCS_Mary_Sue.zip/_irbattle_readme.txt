SONG URL : http://d11x.sakura.ne.jp/asdf/?p=304
TAG : バラエティ
推定レベル：★26
POINT : [{90*(SCORE/7070)}+0(FAILED) or 5(EASY CLEAR) or 10(GROOVE CLEAR or HARD CLEAR or FULL COMBO)]
COMMENT : 予想より難しかったです。ごめんねぇー　…そんなに難しそうじゃなかったけどね

02.bml基準ズレ抜けなし。