IR battle venue
https://darksabun.github.io/event/irbattle/

本体URL
http://wayback.archive.org/web/20081003060805/http://placase.bms.ms:80/data/bms/pla_futago.rar

[ (^^)IR（高速乱打）]
推定難易度: st11~

Point expression
int lamp, pgr, gr, g
%% lamp: clear=1, failed=0
%% pgr, gr, g: the number of perfectgreat, great, good each

if lamp=1
	score=100;
else
	score=round( 100(1 - exp( -(exscore)/2 ) );

Comment
weird thing again
intended delay(additional keysound) exists