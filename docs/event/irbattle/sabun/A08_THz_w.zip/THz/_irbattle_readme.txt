Title: THz [皿W]

Obj: w

本体/Song URL: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=190&event=133

タグ/Tag: A08 初級者（スクラッチ）

推定難易度/Estimated Difficulty: ★6

Zure check: THz_Hyper_1.bms

ポイント式/Point Expression (PYTHON): 
```python
# clear: 0=FAILED, 1=EASY, 2=NORMAL, 3=HARD, 4=FULLCOMBO, 5=PERFECT
# 9*ex_score//(total_notes*2): 5=B, 6=A, 7=AA, 8=AAA, 9=MAX

def point_function(clear, ex_score, total_notes):
    return ( 
        [0,10,20,40,55,55][clear] +
        [0,0,0,0,0,0,10,30,45,45][9*ex_score//(total_notes*2)]
    )
```

ポイント説明/Point Explanation:

# CLEAR
>=EASY: +10
>=NORMAL: +10
>=HARD: +20
>=FULLCOMBO: +15

# GRADE
>=A: +10
>=AA: +20
>=AAA: +15

-------------------
Comment: 

Making a scratch sabun chart can be awkward. Most of the time, the pattern of the scratches are determined by the song itself, not the chart maker. Because of this, the scratch patterns usually can't be changed much from the default charts. Also, most of the time, the default charts for "scratch" songs are already quite fun to play, so there is little need to make a sabun.

This leaves us with a few options when making a scratch sabun:
1. Find a "scratch" song, with fun scratch rhythms, but the default charts are not well balanced or the notes do not flow well with the scratch rhythm. We can make a more balanced sabun chart.
2. Find a "scratch" song, where many of the "scratch" keysounds are not included in the chart.
3. Make a scratch sabun from a non-scratch song (using keysounds which are not normally used for scratch, like scratch snares, scratch piano etc)

I didn't want to do (3), so I tried to look for (1) or (2). I think THz belongs to category (2). THz [7k Another] already has plenty of scratch, and is also quite fun to play, but many of the scratch keysounds are not used in the chart. I wanted to try making a chart that makes use of most of these scratch keysounds.

I started by moving all of the scratch keysounds (vocals, scratch sounds etc) to the scratch lane. This is so that I don't miss any scratch keysounds later. When making the chart, I would move notes from the scratch lane back to the B lanes if the scratches are not appropriate.

When I start charting the notes, I quickly realized that while the song is great, the keysounding of this BMS is horrible. All of the labels 01-ZZ are used, and it seems like many of the keysounds were left uncut because they ran out of keysound labels. Also, it seems like all of the hat_###.ogg and snare2_###.ogg keysounds (N4~M2) are not present in the song folder, so there are a lot of silent keysounds in the song. I wonder if those keysounds were intentionally removed, or the artist forgot to include the keysounds in the download. There are also very few useable keysound objects for charting, so I tried to make tricky patterns with few notes.

I have a rule when using blank keysounds. I will only use blank keysounds to make chords larger. However, because all keysound labels (01-ZZ) are already used, it was difficult for me to use blank keysounds. After a bit of searching, I noticed keysound M9=snare2_000.ogg is not used anywhere in the chart. So I deleted the definition #WAVM9 snare2_000.ogg and used M9 for blank keysounds. This way, the chart passes the keysound misalignment check.

I still don't have a lot of experience when designing good scratch charts, but I have a few theories.
1. There should be breaks in the scratch patterns. If there are no breaks, it would be difficult to recover from a single BAD chain. It is also good to allow the player to "reset" their hand position on the turntable.
2. Scratch is difficult for timing, so I think having a few regular notes makes timing easier.
3. Memorizing scratch rhythms is common. It is important for the scratch rhythm to match the music well, so that the player can learn the rhythm easily.

To make the chart fun to play, in the gaps between scratch chains, I tried to use patterns that are played with both hands (LN or large chords). During scratch chains, I often use patterns that can be played with one hand. I think switching between 1-hand and 2-hand playstyles is fun.

Overall, it was a tricky chart to make, but I hope the final chart is fun.

I am not sure how to rate the difficulty of this chart. Probably somewhere between ★5 and ★8.

Time spent: ~1 week

-------------------

IR BATTLE: https://darksabun.github.io/event/irbattle/

Website:https://wcko87.github.io/
Twitter:https://twitter.com/wcko87
自作譜面の難易度表:https://wcko87.github.io/bms-table/obj-w.html