https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

本体URL 
http://manbow.nothing.sh/event/event.cgi?action=More_def&num=1&event=54
[ 初級者IR（DARKSABUN）]
推定難易度: B-6

Point expression 
max(0, (combo-20)/5)

Comment
追加音源あり