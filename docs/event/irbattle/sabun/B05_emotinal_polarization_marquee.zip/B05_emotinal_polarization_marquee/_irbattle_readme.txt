https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

Song URL 
http://manbow.nothing.sh/event/event.cgi?action=More_def&num=79&event=135
[中級者IR（高速乱打）]

Difficulty : ★18

Point expression
레이트 점수 (Max 80pts)
SCORE RATE÷1.25 (소수점 반올림)

콤보 점수 (Max 10pts)
0 = 0pts
1~754 = 3pts
755~1509 = 7pts
1510~2264 = 10pts

클리어 점수 (Max 10pts)
EASY CLEAR = 5pts
CLEAR = 7pts
HARD CLEAR = 10pts

Comment
순수 지력계로 만들어 보았습니다.

엇갈림 없음 (_EP_7I.bms 기준)