SONG URL : https://web.archive.org/web/20200607062139/http://sunaneko.iptime.org/BMS_Library/%E3%82%B7%E3%83%A5%E3%83%AA%20(by%20%E3%82%B7%E3%82%A3%E3%83%8A%20%C3%97%20A.M.).rar
TAG : HARD判定
推定レベル：★20?
POINT : [{60*(SCORE/4488)}+10(FAILED) or 20(EASY CLEAR) or 30(GROOVE CLEAR) or 40(HARD CLEAR or FULL COMBO)]

COMMENT 
イージー判定シュリ：http://www.dream-pro.info/~lavalse/LR2IR/search.cgi?mode=ranking&bmsid=287083
ノーマル判定シュリ：http://www.dream-pro.info/~lavalse/LR2IR/search.cgi?mode=ranking&bmsid=287082
ハード判定シュリ：これ
ベリーハード判定シュリ：http://www.dream-pro.info/~lavalse/LR2IR/search.cgi?mode=ranking&bmsid=287081
シュリコンプリート

[shu_bms002]'.bme 基準ズレ抜けなし。