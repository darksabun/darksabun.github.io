For LR2IR BATTLE
https://darksabun.github.io/event/irbattle/

Music Download: https://dl.dropboxusercontent.com/s/04qc54sm8jwd0jf/Kreuz.zip

D06 - (^^)IR�i�f�B���C�j
����5 / st7~8?

Uses Another chart as base.
Density structure is similar to ���҃^�C�� / TechnoBreak.

Point Expression formula:
max(((exscore-2280)/2280)*25,0) + clearlamp*7 + min(clearlamp,1)*40

Apologies for any kind of pain it may cause.