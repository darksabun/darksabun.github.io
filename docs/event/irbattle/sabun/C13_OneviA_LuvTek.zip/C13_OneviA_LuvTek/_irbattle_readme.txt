https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

本体URL 
https://bms.kyouko.moe/torrent/BMS_Library/OneviA%20(by%20gmtn.).rar
[上級者IR（DARKSABUN）]
推定難易度: B4-?

Point expression 
min( 100, [0,10,30,50][min(clear,3)]+max(0, (150-BP)/3)+10*(EXscore/(2*totalNotes)) )

Comment
오랜만에 만들어보는 정통파(?) 변속 차분입니다.
변속 처리력 복구를 위한 차분으로, 노트 난이도 및 기믹 모두 아주 어렵게 만들지는 않았습니다.