|=-------------------------=|
|=---[ ゴフェルの木棺 -IR- ]---=|
|=-=-=-=-=-=-=-=-=-=-=-=-=-=|
|=-------[ Sentire ]-------=|
|=-[ C10 ]---[ obj. sera ]-=|
|=-------------------------=|

--[ URL

https://onedrive.live.com/?authkey=%21ALgMo7JGGuveCzQ&id=647B6478EB5B0459%21108&cid=647B6478EB5B0459

--[ TAG

커튼/カーテン/Curtain LN

--[ Estimated difficulty

◆23

--[ Point expression

exscore/5236*40+lamp*12

--[ Comments

Very scale-y and BS fumen with a bit of randa inverse. The ending is hard and there's little recovery, but if you can clear at all, you can get a lot of points...
May or may not be good with random.
Takes a lot of pattern bases from the original Normal.

No zure from gofe_n_bga.bms(d14b015d05720e8482d0643db8af8330)