(2021-07-18 chart file updated)
https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

本体URL 
http://web.archive.org/web/20040411171700/http://in-bpms.hp.infoseek.co.jp:80/BMS2.htm
[上級者IR（主催）]
推定難易度: ★23?

Point expression 
min(100, (min(30,clear*10) if clear<1 and clear>2 else clear*10+5) + max(0, (160-BP)/4) + 25*(EXscore/(2*totalNotes)) + log2(maxcombo) )
Therefore, for clear: failed 0pts, EC 15pts, GC 25pts, HC 30pts

Comment
追加音源によるズレあり
화학공학 전공을 학부 4년동안 이수했지만, 정작 무얼 배웠는지는 모르겠습니다.