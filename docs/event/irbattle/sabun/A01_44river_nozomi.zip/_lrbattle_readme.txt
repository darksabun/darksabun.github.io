https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)
 
Song URL : https://onedrive.live.com/?cid=FC95A680740CA8C9&id=FC95A680740CA8C9%21292&parId=FC95A680740CA8C9%21111
Difficulty : sl4(★7)

Point expression
성과 A의 숫자만큼 10씩 추가 (최대 3회 중복) 
풀콤보 30/하드클 25/노멀클 20/이지클 15
맥스콤보 퍼센트 비율로 최대 40점까지 반영

Comment 
すべての追加音は追加音です。
모든 일그러짐음은 추가음입니다.

하이볼 전략으로 일급을 1달러에서 4달러로 올린 모 현대드라마 드립은 폭★8 되었습니다.
제목도 이전 명의에 썼던 ABNORMAL로 쓰겠습니다.

제 데뷔 차분인 The Phantom of Sanctuary (ABNORMAL)과 유사한 방식으로 짰고, 이곡도 중간마다 연타 따닥이가 있습니다.

토탈치 444 -> 460.4 (08/10~11일 기준으로 4달러 환율로 변경하였습니다.)

"★4는 너무 적소. sl4로 합시다"