https://darksabun.github.io/event/irbattle/
(LR2IR BATTLE event page)

本体URL 
http://manbow.nothing.sh/event/event.cgi?action=More_def&num=262&event=133
[(^^)IR（連打複合）]
推定難易度:st7?

Point expression 
min(100, 10*min(clear,3)+max(0, (150-BP)/3)+30*(score/(2*totalNotes)) )

Comment
PRO is an abb. for Prototype