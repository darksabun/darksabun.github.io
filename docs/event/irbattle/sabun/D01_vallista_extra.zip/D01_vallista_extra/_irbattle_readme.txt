LR2IR BATTLE Event Page: https://darksabun.github.io/event/irbattle/
Difficulty/難易度: (^^)IR微連打
★★5?/st7~8 
本体URL: http://uploader.bms.ms/data/bof2011/sakuzyo_vallista_ogg.zip

Point expression:
(clear * 10) + (exscore / totalnotes) * 35 + max(0, (150 - B+P) / 10)
clear bonus:
fail: 0
easy: 10
clear: 20
hard: 30
fullcombo: 40
p-attack: 50
g-attack: why
lunaris: whywhy
min score:
0
max score:
100

You better like mini jacks
あなたは微連打が好きでなければなりません