DP☆4/☆9/★1/★7 Rainy Float

BMS URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=286&event=149

No Misalignment (Based on 'RainyFloat_noPlace.bms.sabun')