Xerynth Zorok [wbr]
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=309&event=149

[Stiila] based:spa st6?
227乱打。多少の偏りがあったりなかったり。