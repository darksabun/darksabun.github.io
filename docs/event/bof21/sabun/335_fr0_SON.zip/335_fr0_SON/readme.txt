Hero[Neon Sign] obj.SON
本体リンク:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=335&event=149
推定難易度:☆10
agさんが制作された[7keys HYPER]譜面をベースに制作しました
