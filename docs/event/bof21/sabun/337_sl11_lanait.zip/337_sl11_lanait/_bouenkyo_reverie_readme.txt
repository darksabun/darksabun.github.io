望遠鏡にて天際へ傾く [REVERIE] sl11
obj.Lanait

本体: 
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=337&event=149