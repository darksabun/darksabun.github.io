・sl3?　他界、境、再会。【かつたこザー】

・本体リンク：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=57&event=149

・bms diff toolを使用し同梱Anotherを比較対象にし確認でズレ、抜け無し