Song URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=217&event=149
Difficulty: ★7/sl4/so4 (The scratches may be too gimmicky for satellite?)

Bursting through my charting atrophy.
Honestly, I still see myself as a bit of a beginner charter, so hopefully this is good.
Thank you for playing!