RNY_flarionix
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=31&event=149

[Stiila] st6? based:spa

7型多めの190乱打。st6～7の長時間続く200乱打への足掛かりのつもりで作った。
中盤の4-3、3-3地帯が一番むずいかも。