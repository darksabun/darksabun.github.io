本体リンクhttps://manbow.nothing.sh/event/event.cgi?action=More_def&num=54&event=149

推定難易度:st0