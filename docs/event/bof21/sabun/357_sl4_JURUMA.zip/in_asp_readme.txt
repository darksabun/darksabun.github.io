・Song URL : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=357&event=149

・Difficulty: sl4