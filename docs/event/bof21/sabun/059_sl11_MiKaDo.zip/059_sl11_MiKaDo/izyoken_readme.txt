本体URL:https://manbow.nothing.sh/event/event.cgi?action=More_def&num=59&event=149

sl11?

同梱ANOTHER譜面とズレ抜け無し 