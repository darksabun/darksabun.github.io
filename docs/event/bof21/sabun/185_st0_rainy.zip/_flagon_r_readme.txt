"Flagon" / Lemi.

venue: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=185&event=149

st0? i'm not sure