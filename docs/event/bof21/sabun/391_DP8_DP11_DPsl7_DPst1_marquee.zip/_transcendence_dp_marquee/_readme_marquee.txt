DP☆8/☆11(☆11.4)/★7/★11(DPst1) Transcendence

BMS URL
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=391&event=149

No Misalignment (Based on 'Transcendence_BASE.bms')