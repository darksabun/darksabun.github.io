URL : https://manbow.nothing.sh/event/event.cgi?action=More_def&num=35&event=149

DPN ☆3
DPH ☆7
DPA sl0~1