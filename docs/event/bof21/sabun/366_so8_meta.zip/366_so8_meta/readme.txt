[本体URL]
https://manbow.nothing.sh/event/event.cgi?action=More_def&num=366&event=149

[ズレ抜け]
同梱__raw.xxxとズレ抜け無し（stagefile.pngのみ設定）

[NOTES / TOTAL]
2025 notes / 468 (0.231)

[雑記]
微縦、LN、混フレなどの総合譜面
前半は曲調に合わせて密度のある繰り返し
後半は発狂BMSらしくない密度でもボス曲らしさを感じられるように
最初と最後の難所を対にしているのがオシャレポイント
★13(so8)くらいのつもりだけどラス殺しのためハード難

[譜面リファレンス]
Almagest / Galdeira
DORNWALD ～Junge～ / DJ TOTTO
EMERALDAS / HuΣeR vs. dj Hellix
BLACK or WHITE? / BlackYooh vs. siromaru
