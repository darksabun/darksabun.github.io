BMS chart Editors’ League
https://darksabun.github.io/event/bcel/venue/

BMS SEARCH venue: BMS chart Editors’ League -Final-
https://venue.bmssearch.net/bcel_final

URL: https://dropbox.bms.ms/u/37251493/PUPA.zip
Difficulty: sl12
Comment: PUPA[SPB].bme基準、追加音源あり
皿はライトに、難易度はわかりませんので上限に