BMS chart Editors’ League
https://darksabun.github.io/event/bcel/venue/

BMS SEARCH venue: BMS chart Editors’ League -Preliminary-
https://venue.bmssearch.net/bcel_pre

URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=260&event=96
Difficulty: sl4
Comment: futurity_a.bms基準 追加音源あり
キー音を切って配置することに意義を置きました。