I am so, so sorry
the difficulty is set at 80 because it's mercury's atomic number
i hope this is not too difficult for middle class, i made the ending easier to compensate i guess, there's some recovery