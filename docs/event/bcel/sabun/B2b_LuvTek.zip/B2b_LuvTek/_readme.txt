BMS chart Editors’ League
https://darksabun.github.io/event/bcel/venue/

BMS SEARCH venue: BMS chart Editors’ League -Preliminary-
https://venue.bmssearch.net/bcel_pre

URL: https://9domu46i.com/yuruyuru/phase7.html
Difficulty: st2
Comment: __night_view_.template基準
短距離走で耐えるために密度の低い地帶で着実に回復してください。