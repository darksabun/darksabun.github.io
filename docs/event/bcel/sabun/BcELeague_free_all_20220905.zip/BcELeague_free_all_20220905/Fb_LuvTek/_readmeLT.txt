BMS chart Editors’ League
https://darksabun.github.io/event/bcel/venue/

BMS SEARCH venue: BMS chart Editors’ League -Freestyle-
https://venue.bmssearch.net/bcel_free

URL: https://mega.nz/folder/FNFDCQaT#wfv-iI4UuSIaGpP0oFZdtQ/file/QQVkUZ4Y
Difficulty: B3 (~★★3?)
Comment: eFeL_KHTP_Beat_Cannon_00_blank.bmx基準
(>ω^)/