BMS chart Editors’ League
https://darksabun.github.io/event/bcel/venue/

BMS SEARCH venue: BMS chart Editors’ League -Freestyle-
https://venue.bmssearch.net/bcel_free

URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=185&event=137
Difficulty : ★22? 
Comment: どうもMary_Sueです。ナンセンスな譜面を持って帰りました  よろしくね

_empty_N基準ズレ抜けなし。