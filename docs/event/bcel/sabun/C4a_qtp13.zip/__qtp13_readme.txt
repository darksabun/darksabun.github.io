Retronika [Ekstrem]
Estimate difficulty: ★22~ (st2~3? Hardest parts hovers around st3~4, lots of free recovery)

* Includes bonus chart (not used for contest representation)

A tricky chart to balance in my opinion.
The bonus chart was my first attempt at it, trying for an st5~6 range but ended up being too disjointed, so I have to rethink the chart's difficulty structure.
And still the balance of the reworked chart feels kinda off somewhat...

* Used Empty file as base.
