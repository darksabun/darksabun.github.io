本体：https://manbow.nothing.sh/event/event.cgi?action=More_def&num=481&event=137
_NORMAL準拠