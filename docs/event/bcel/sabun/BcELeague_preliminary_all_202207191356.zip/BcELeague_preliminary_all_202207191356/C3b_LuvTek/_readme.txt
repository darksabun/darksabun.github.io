BMS chart Editors’ League
https://darksabun.github.io/event/bcel/venue/

BMS SEARCH venue: BMS chart Editors’ League -Preliminary-
https://venue.bmssearch.net/bcel_pre

URL: http://manbow.nothing.sh/event/event.cgi?action=More_def&num=74&event=132
Difficulty: st5
Comment: _0._bms基準
皿とガチ押しdualathonするエイリアン