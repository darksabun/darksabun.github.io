BMS chart Editors’ League
https://darksabun.github.io/event/bcel/venue/

BMS SEARCH venue: BMS chart Editors’ League -Freestyle-
https://venue.bmssearch.net/bcel_free

URL: https://mega.nz/folder/FNFDCQaT#wfv-iI4UuSIaGpP0oFZdtQ/file/9AVgXCTb
Difficulty: ★18 (~sl11?)
Comment: _papyventure_001.bml基準
やはりテストプレイなしで提出します。
低トータルと様々な要素が旅程を脅かしますが、このアドベンチャーを楽しんでいただきたいです。