BMS chart Editors’ League
https://darksabun.github.io/event/bcel/venue/

BMS SEARCH venue: BMS chart Editors’ League -Preliminary-
https://venue.bmssearch.net/bcel_pre

URL: https://manbow.nothing.sh/event/event.cgi?action=More_def&num=481&event=137
Difficulty: st5
Comment: HYPER.bms基準
序盤は鍵盤がheavy、後半は皿がheavy