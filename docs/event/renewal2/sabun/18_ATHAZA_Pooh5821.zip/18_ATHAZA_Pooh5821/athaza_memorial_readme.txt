Event: GENOCIDE Reinterpretation 2

Original:
Title - ATHAZA[INSANE]
Artist - LeaF
Difficulty - ★18

BMS link: http://leafbms.web.fc2.com/song.html

Reinterpretation:
Title - ATHAZA[MEMORIAL]
Charter - Pooh5821
Difficulty - ★18

Comment:
"Do you remember me?"
"Do you remember my voice?"
...
"It's been so long since I have seen you."
"Can you stay with me for a little longer?"
...
"Please, just one last time."
...
"Thank you."
"Even if I would never see you again, I hope my memories will live on with you."