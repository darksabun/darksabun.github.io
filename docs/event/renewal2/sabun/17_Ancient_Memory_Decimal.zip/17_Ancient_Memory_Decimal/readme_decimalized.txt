Ancient Memory(NOMAL)と比較し、音ズレ無しです。

難易度：★19？
リメイク元: ★17 Ancient Memory (Phantasm)
本体URL: https://drive.google.com/open?id=1ypr6cfcEFs9dtaJXuL9gZkDFyZz-VLPn&usp=drive_fs

折角Solar表Supernova表できたんだから滅茶苦茶slに合わなそうな譜面作りたくなりました。
ただ流石にTOTALを300にする勇気はなかったです。ハイ。

選曲チョイスですが、★17から自分が好きな曲をチョイスした感じです。
この曲NHA譜面それぞれ曲が違うんですよね～。発狂表はA譜面音源の譜面しかないのが勿体ない。
今回はN譜面音源で作ってみました。結構すき。
同梱譜面やってみると意外な発見あって楽しいですよね。