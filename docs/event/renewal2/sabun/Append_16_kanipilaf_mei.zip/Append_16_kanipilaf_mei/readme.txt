特効薬はガチ押しピラフ
セナ / 冥

推定レベル : ★24~25?
本体 : https://web.archive.org/web/20140111153652/http://higehime.main.jp/bms/bof2013/kanipilaf.rar

ガ　チ　押　し