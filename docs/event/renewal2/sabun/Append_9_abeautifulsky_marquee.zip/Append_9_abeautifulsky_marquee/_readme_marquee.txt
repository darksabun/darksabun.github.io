★9(sl5) A BEAUTIFUL SKY

BMS URL
https://ia600304.us.archive.org/view_archive.php?archive=/14/items/recognize_m_bms/recognize_m_bms_collection.rar

No misalignment (Based on 'rm_btsky_another.bme')