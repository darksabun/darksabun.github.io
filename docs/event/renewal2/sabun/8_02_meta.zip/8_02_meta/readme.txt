[本体URL]
https://web.archive.org/web/20200810005433/http://ofuton.tk:80/tarolabo/02.rar

[ズレ抜け]
同梱 02_07_12.bme ベースに作成
他同梱差分と比較し、抜けていると考えられる以下のキー音を追加（Anzu BMS Diff Tool）

#038 01 (0 / 1)	 #WAV7Z is missing in Y. (02_bgm07.wav)
#090 13 (9 / 16) #WAV5K is missing in Y. (02_xpinano08.wav)
#091 14 (9 / 16) #WAV65 is missing in Y. (02_xpinano07.wav)
#094 14 (9 / 16) #WAV5J is missing in Y. (02_xpinano07.wav)

[NOTES / TOTAL]
1702 notes / 360 (0.212)

[BPM]
2 - 1800000002
use MAX-FIX (LR2) / MAIN-BPM (oraja)

[譜面リファレンス]
妖晶零弐 / tarolabo
-Ω-, -ω-, 7key_main, 7key_EX