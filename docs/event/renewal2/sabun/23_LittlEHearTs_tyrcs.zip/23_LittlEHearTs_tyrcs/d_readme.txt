"GENOCIDE Reinterpretation 2" submission
https://darksabun.club/event/renewal2/

Song URL: http://necoco.2-d.jp/bms/nm23_nm05.zip

difficulty: ~★23
the chart contains intentional misalignments for delaying purposes