For GENOCIDE Reinterpretation 2

Original Chart: ★3 CHERRY DOLL(Imperial Rose)
Sabun: CHERRY DOLL(YOU'RE MINE)
Difficulty: ★3

I want to try making a version that's easier to play.

R054