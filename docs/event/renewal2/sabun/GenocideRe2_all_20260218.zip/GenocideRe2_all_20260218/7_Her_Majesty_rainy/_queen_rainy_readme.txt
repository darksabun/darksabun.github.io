song url: https://mega.nz/#F!UFsB0YyB!kwwXNr3CgJq-FvL19myHcA

sabun event: GENOCIDE Reinterpretation 2 (https://darksabun.club/event/renewal2/)

original chart: ★7 Her Majesty [Another+]
reinterpreted chart: ★8? Her Majesty [Re:Another]

comment: 
원본 [Another+] 차분의 104번째 마디에 '1G' 키음이 POOR 레인에 들어가있는 것을 추가로 수정하였습니다.
fixed the '1G' keysound being incorrectly placed in the POOR lane at measure 104 of the original [Another+] chart.