Lucid Delayming
TiS feat. maho / 冥

推定レベル : ★???
本体 : http://manbow.nothing.sh/event/event.cgi?action=More_def&num=144&event=88

ディレイ楽しい