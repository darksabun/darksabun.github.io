夢人形-marionette dreamer- [Rebirth]

・Song URL : https://drive.google.com/file/d/14AD6EtWlfmrO3SeDds5HsGSy4Fy7gcCW/view?usp=drive_link

・Difficulty: ★7

7Key譜面と比較してズレ無を確認(★7の譜面は改変が入っているため)/72小節目のおそらくミスであろうスネアの二重配置を削除