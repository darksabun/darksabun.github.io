ダークサンバランド
ダークサンバマスター佐藤 -SATOH-

obj. Atharnal

本体 : https://web.archive.org/web/20140111162448/http://red-image.net/dl/DarkSambaLand.rar
算定難易度 : ★24 (st/sn5)


Deep L Translate:

 LAST BOSSの皿使用を尊重しつつ、ガチ押しとして再構築してみました。 
皿が過激すぎる部分は少し整えました。（大きな違いはありません）


-Atharnal (discord : Atharnal#2977)