원본 패턴 : ★23 M-A (KOOKY)
재해석 패턴 : ★23 M-A (FORCEFUL)
재해석한 이유 : Trendy한 패턴이 없어서
본체URL : https://web.archive.org/web/20160921143843/http://abeyuta27272.sakura.ne.jp/bms/M-A.rar