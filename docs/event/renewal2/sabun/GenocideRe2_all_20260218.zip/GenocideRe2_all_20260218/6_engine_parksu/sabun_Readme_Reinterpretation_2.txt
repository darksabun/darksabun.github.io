원본 패턴: ★6 Engine [SP Insane]
재해석 패턴: ★6 Engine [TCe 300]
재해석한 이유: EZ2ON Style
본체 URL: https://mega.nz/folder/FNFDCQaT#wfv-iI4UuSIaGpP0oFZdtQ/file/ZcVlXSAS
기타 코멘트: Maximum Power

原譜面: ★6 Engine [SP Insane]
リメイク譜面: ★6 Engine [TCe 300]
リメイクした理由: EZ2ON Style
本体URL: https://mega.nz/folder/FNFDCQaT#wfv-iI4UuSIaGpP0oFZdtQ/file/ZcVlXSAS
コメント: Maximum Power

Original Chart: ★6 Engine [SP Insane]
Reinterpreted chart: ★6 Engine [TCe 300]
Reason for reinterpretation: EZ2ON Style
BMS URL: https://mega.nz/folder/FNFDCQaT#wfv-iI4UuSIaGpP0oFZdtQ/file/ZcVlXSAS
Other comments: Maximum Power