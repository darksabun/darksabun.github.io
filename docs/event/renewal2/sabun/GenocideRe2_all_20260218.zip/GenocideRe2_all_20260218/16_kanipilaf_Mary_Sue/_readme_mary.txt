特効薬はカニピラフ (渋面)
セナ/差分Mary_Sue

本体：https://web.archive.org/web/20140111153652/http://higehime.main.jp/bms/bof2013/kanipilaf.rar

_kanipilaf_02基準ズレ抜けなし
よろしくお願いします。

2026/02/08
Mary_Sue