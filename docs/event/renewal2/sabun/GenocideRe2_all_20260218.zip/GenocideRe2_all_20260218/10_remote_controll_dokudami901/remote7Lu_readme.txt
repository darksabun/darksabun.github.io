「GENOCIDE Reinterpretation 2」参加作品
https://darksabun.club/event/renewal2/

URL:http://web.archive.org/web/20040814034345/http://www.is-m.jp/music/bms/list/history/
元譜面:★10
難易度:★11

くらえ！地力譜面になるビ～～～ム( ﾟДﾟ)にｱ 弌弌弌弌弌弌弌弌弌弌弌弌弌弌弌弌弌弌弌弌⊃

うわあああぁぁぁぁ！！！結構キモい譜面になったああああぁぁぁぁぁ！！！



…微縦はやっぱ難しいなぁ