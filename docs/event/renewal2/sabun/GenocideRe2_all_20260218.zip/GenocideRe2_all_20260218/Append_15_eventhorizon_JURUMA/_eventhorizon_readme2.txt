事象の地平 [Determination]

・Song URL : https://drive.google.com/file/d/1hhstHPlRUZRC9KkYG3oDgW_KS4_rAJ-B/view?usp=drive_link

・Difficulty: ★？？(Too Difficult)

Normal譜面と比較してズレ無を確認(Another譜面がズレているので)