曲本体リンク：https://archive.org/download/sentire_bms/HaL_bms_collection.rar/HaL_bms_collection%2FArcadia_HQ_withBGA_rr6.rar
担当したレベル：★1
推定レベル：★9