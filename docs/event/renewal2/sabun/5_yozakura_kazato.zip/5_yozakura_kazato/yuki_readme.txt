"GENOCIDE Reinterpretation 2" submission
https://darksabun.club/event/renewal2/

Song URL: https://mega.nz/folder/EpgWgJqa#7OItZfYLQxZ0X8OB19yvNQ/file/FhY3FagI

difficulty: ★5
自分好みに叩きやすく作ってみました。