曲DLリンク（直リンク注意！）：https://dropbox.bms.ms/u/28765267/er_baby-frenzy.zip
推定レベル：★14?
元譜面：_BabyFrenzy（未配置譜面）
※元譜面とのズレ抜けなし
コメント：ほどよくエッジの効いた譜面を目指しました。