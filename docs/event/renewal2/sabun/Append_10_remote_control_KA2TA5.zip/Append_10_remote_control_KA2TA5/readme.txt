本体リンク（差分保管所）：https://mega.nz/folder/FNFDCQaT#wfv-iI4UuSIaGpP0oFZdtQ/folder/UB8gABwB
担当レベル：★10
推定レベル：★11