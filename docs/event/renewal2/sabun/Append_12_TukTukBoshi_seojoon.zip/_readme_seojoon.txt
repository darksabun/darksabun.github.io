TITLE:	Tuk Tuk Boshi [SJ]
URL:	https://mega.nz/folder/FNFDCQaT#wfv-iI4UuSIaGpP0oFZdtQ/file/IMtWiAob
LEVEL:	★10? (sl6?)

for 「Genocide Reinterpretation 2」
Original Sabun: ★12 Tuk Tuk Boshi [7keys Crescent]

마지막의 가속 연출 삭제로 인한 일부 엇갈림이 있습니다. 이외에는 동봉 하이퍼와 엇갈림 없음.
最後の加速演出削除による一部ズレがあります。それ以外は同梱HYPERとズレなし。

원본 패턴은 다양한 데님 형태를 연습할 수 있어서 좋다고 생각합니다만,
일부 구간에서 어떤 키음을 활용했는지 조금 알기 힘들게 배치된 느낌이어서 아쉬웠습니다.
어떤 키음을 표현했는지 알기 쉽게 하면서도 너무 반복적인 배치는 지양하려고 노력했습니다.
(제 의도대로 패턴이 나왔는지는 모르겠지만요)
원본 패턴에 비해 고밀도 구간 사이사이에 쉬는 지점이 많고 연타도 적어서 난이도는 확실히 쉬워졌습니다.

2026.1.28	seojoon