For GENOCIDE Reinterpretation 2

BMS: https://onedrive.live.com/?id=FC95A680740CA8C9%21111&cid=FC95A680740CA8C9
Original Chart: ★11 Ena (Radio mix) -vaca- (obj:NWN)
Estimated Difficulty: ★10

Personally, I wasn't a fan of the original chart's sudden high density sections and jacks, as well as the low total.
I made my chart to be more evenly distributed. It may not have as much "bite" as the original, but I think it's fairer at least.
