★5(sl3) 雪月夜鐘 [Maniac]

BMS URL
http://aquaseeds.net/archives/rickytick_bell_hq.rar

No misalignment (Based on '_rickytick_bell_temp_increased')

---
0Notes template file:
_rickytick_bell_temp - Based on 'rickytick_bell_7a.bme'
_rickytick_bell_temp_increased - Increased notes from '_rickytick_bell_temp' (All piano sounds. No musical changes)