曲本体リンク：http://dl.dropboxusercontent.com/s/0ekt0hu22o5npq5/Lucifer_ogg.zip?e=1
担当レベル：★9
推定レベル：★7？